#define INET_FULL
#include <rules.h>
#include <windows.h>

#include <dplay8.h>
//#include <dplobby8.h>
#include <dvoice.h>

#pragma warning(push, 3)
#include <vector>
#include <stack>
#include <set>
#pragma warning(pop)

#include <inet2.h>
#include <c_buffer.h>
#include <c_unknwn.hpp>
#include <C_str.hpp>
#include <smartptr.h>
#include <i3d\i3D_math.h>

#ifdef _MSC_VER
using namespace std;
#endif

