#include "all.h"

//-------------------------------------
void DP_Fatal(char *text, HRESULT hr){

   char *msgp;
   switch(hr){

   case DPNERR_ABORTED: msgp = "The operation was canceled before it could be completed."; break;
   case DPNERR_ADDRESSING: msgp = "The address specified is invalid."; break;
   case DPNERR_ALREADYCONNECTED: msgp = "The object is already connected to the session."; break;
   case DPNERR_ALREADYCLOSING: msgp = "An attempt to call the Close method on a session has been made more than once."; break;
   case DPNERR_ALREADYDISCONNECTING: msgp = "The client is already disconnecting from the session."; break;
   case DPNERR_ALREADYINITIALIZED: msgp = "The object has already been initialized."; break;
   case DPNERR_BUFFERTOOSMALL: msgp = "The supplied buffer is not large enough to contain the requested data."; break;
   case DPNERR_CANNOTCANCEL: msgp = "The operation could not be canceled."; break;
   case DPNERR_CANTCREATEGROUP: msgp = "A new group cannot be created."; break;
   case DPNERR_CANTCREATEPLAYER: msgp = "A new player cannot be created."; break;
   case DPNERR_CANTLAUNCHAPPLICATION: msgp = "The lobby cannot launch the specified application."; break;
   case DPNERR_CONNECTING: msgp = "The method is in the process of connecting to the network."; break;
   case DPNERR_CONNECTIONLOST: msgp = "The service provider connection was reset while data was being sent."; break;
   case DPNERR_DATATOOLARGE: msgp = "The application data is too large for the service provider's Maximum Transmission Unit."; break;
   case DPNERR_DOESNOTEXIST: msgp = "Requested element is not part of the address."; break;
   case DPNERR_ENUMQUERYTOOLARGE: msgp = "The query data specified is too large."; break;
   case DPNERR_ENUMRESPONSETOOLARGE: msgp = "The response to an enumeration query is too large."; break;
   case DPNERR_EXCEPTION: msgp = "An exception occurred when processing the request."; break;
   case DPNERR_GENERIC: msgp = "An undefined error condition occurred."; break;
   case DPNERR_GROUPNOTEMPTY: msgp = "The specified group is not empty."; break;
   case DPNERR_HOSTREJECTEDCONNECTION: msgp = "The DPN_MSGID_INDICATE_CONNECT system message returned something other than S_OK in response to a connect request."; break;
   case DPNERR_HOSTTERMINATEDSESSION: msgp = "The host in a peer session (with host migration enabled) terminated the session."; break;
   case DPNERR_INCOMPLETEADDRESS: msgp = "The address specified is not complete."; break;
   case DPNERR_INVALIDADDRESSFORMAT: msgp = "Address format is invalid."; break;
   case DPNERR_INVALIDAPPLICATION: msgp = "The GUID supplied for the application is invalid."; break;
   case DPNERR_INVALIDCOMMAND: msgp = "The command specified is invalid."; break;
   case DPNERR_INVALIDDEVICEADDRESS: msgp = "The address for the local computer or adapter is invalid."; break;
   case DPNERR_INVALIDFLAGS: msgp = "The flags passed to this method are invalid."; break;
   case DPNERR_INVALIDGROUP: msgp = "The group ID is not recognized as a valid group ID for this game session."; break;
   case DPNERR_INVALIDHANDLE: msgp = "The handle specified is invalid."; break;
   case DPNERR_INVALIDHOSTADDRESS: msgp = "The specified remote address is invalid."; break;
   case DPNERR_INVALIDINSTANCE: msgp = "The GUID for the application instance is invalid."; break;
   case DPNERR_INVALIDINTERFACE: msgp = "The interface parameter is invalid. This value will be returned in a connect request if the connecting player was not a client in a client/server game or a peer in a peer-to-peer game."; break;
   case DPNERR_INVALIDOBJECT: msgp = "The DirectPlay object pointer is invalid."; break;
   case DPNERR_INVALIDPARAM: msgp = "One or more of the parameters passed to the method are invalid."; break;
   case DPNERR_INVALIDPASSWORD: msgp = "An invalid password was supplied when attempting to join a session that requires a password."; break;
   case DPNERR_INVALIDPLAYER: msgp = "The player ID is not recognized as a valid player ID for this game session."; break;
   case DPNERR_INVALIDPOINTER: msgp = "Pointer specified as a parameter is invalid."; break;
   case DPNERR_INVALIDPRIORITY: msgp = "The specified priority is not within the range of allowed priorities, which is inclusively from 0 through 65535."; break;
   case DPNERR_INVALIDSTRING: msgp = "String specified as a parameter is invalid."; break;
   case DPNERR_INVALIDURL: msgp = "Specified string is not a valid DirectPlay URL."; break;
   case DPNERR_INVALIDVERSION: msgp = "There was an attempt to connect to an invalid version of DirectPlay."; break;
   case DPNERR_NOCAPS: msgp = "The communication link that DirectPlay is attempting to use is not capable of this function."; break;
   case DPNERR_NOCONNECTION: msgp = "No communication link was established."; break;
   case DPNERR_NOHOSTPLAYER: msgp = "There is currently no player acting as the host of the session."; break;
   case DPNERR_NOINTERFACE: msgp = "The interface is not supported."; break;
   case DPNERR_NORESPONSE: msgp = "There was no response from the specified target."; break;
   case DPNERR_NOTALLOWED: msgp = "Object is read-only; this function is not allowed on this object."; break;
   case DPNERR_NOTHOST: msgp = "An attempt by the client to connect to a nonhost computer. Additionally, this error value may be returned by a nonhost that tries to set the application description."; break;
   case DPNERR_OUTOFMEMORY: msgp = "There is insufficient memory to perform the requested operation."; break;
   case DPNERR_PENDING: msgp = "Not an error, this return indicates that an asynchronous operation has reached the point where it is successfully queued. SUCCEEDED(DPNERR_PENDING) will return TRUE. This error value has been superseded by DPNERR_SUCCESS, which should be used by all new applications. DPNERR_PENDING is only included for backward compatibility."; break;
   case DPNERR_PLAYERLOST: msgp = "A player has lost the connection to the session."; break;
   case DPNERR_PLAYERNOTREACHABLE: msgp = "A player has tried to join a peer-peer session where at least one other existing player in the session cannot connect to the joining player."; break;
   case DPNERR_SESSIONFULL: msgp = "The request to connect to the host or server failed because the maximum number of players allotted for the session has been reached."; break;
   case DPNERR_TIMEDOUT: msgp = "The operation could not complete because it has timed out."; break;
   case DPNERR_UNINITIALIZED: msgp = "The requested object has not been initialized."; break;
   case DPNERR_UNSUPPORTED: msgp = "The function or feature is not available in this implementation or on this service provider."; break;
   case DPNERR_USERCANCEL: msgp = "The user canceled the operation."; break;

   case DV_OK: msgp = "The request completed successfully."; break;
   case DV_FULLDUPLEX: msgp = "The sound card is capable of full-duplex operation."; break;
   case DV_HALFDUPLEX: msgp = "The sound card can only be run in half-duplex mode."; break;
   case DVERR_BUFFERTOOSMALL: msgp = "The supplied buffer is not large enough to contain the requested data."; break;
   case DVERR_EXCEPTION: msgp = "An exception occurred when processing the request."; break;
   //case DVERR_GENERIC: msgp = "An undefined error condition occurred."; break;
   case DVERR_INVALIDFLAGS: msgp = "The flags passed to this method are invalid."; break;
   case DVERR_INVALIDOBJECT: msgp = "The DirectPlay object pointer is invalid."; break;
   //case DVERR_INVALIDPARAM: msgp = "One or more of the parameters passed to the method are invalid."; break;
   case DVERR_INVALIDPLAYER: msgp = "The player ID is not recognized as a valid player ID for this game session."; break;
   case DVERR_INVALIDGROUP: msgp = "The group ID is not recognized as a valid group ID for this game session."; break;
   case DVERR_INVALIDHANDLE: msgp = "The handle specified is invalid."; break;
   //case DVERR_OUTOFMEMORY: msgp = "There is insufficient memory to perform the requested operation."; break;
   case DVERR_PENDING: msgp = "Not an error, this return indicates that an asynchronous operation has reached the point where it is successfully queued."; break;
   //case DVERR_NOTSUPPORTED: msgp = "The operation is not supported."; break;
   //case DVERR_NOINTERFACE: msgp = "The specified interface is not supported. Could indicate using the wrong version of DirectPlay."; break;
   case DVERR_SESSIONLOST: msgp = "The transport has lost the connection to the session."; break;
   case DVERR_NOVOICESESSION: msgp = "The session specified is not a voice session."; break;
   case DVERR_CONNECTIONLOST: msgp = "The connection to the voice session has been lost."; break;
   case DVERR_NOTINITIALIZED: msgp = "The IDirectPlayVoiceClient::Initialize or IDirectPlayVoiceServer::Initialize method must be called before calling this method."; break;
   case DVERR_CONNECTED: msgp = "The DirectPlayVoice object is connected."; break;
   case DVERR_NOTCONNECTED: msgp = "The DirectPlayVoice object is not connected."; break;
   case DVERR_CONNECTABORTING: msgp = "The connection is being disconnected."; break;
   case DVERR_NOTALLOWED: msgp = "The object does not have the permission to perform this operation."; break;
   case DVERR_INVALIDTARGET: msgp = "The specified target is not a valid player ID or group ID for this voice session."; break;
   case DVERR_TRANSPORTNOTHOST: msgp = "The object is not the host of the voice session."; break;
   case DVERR_COMPRESSIONNOTSUPPORTED: msgp = "The specified compression type is not supported on the local computer."; break;
   case DVERR_ALREADYPENDING: msgp = "An asynchronous call of this type is already pending."; break;
   //case DVERR_ALREADYINITIALIZED: msgp = "The object has already been initialized."; break;
   case DVERR_SOUNDINITFAILURE: msgp = "A failure was encountered initializing the sound card."; break;
   case DVERR_TIMEOUT: msgp = "The operation could not be performed in the specified time."; break;
   case DVERR_CONNECTABORTED: msgp = "The connect operation was canceled before it could be completed."; break;
   case DVERR_NO3DSOUND: msgp = "The local computer does not support 3-D sound."; break;
   case DVERR_ALREADYBUFFERED: msgp = "There is already a user buffer for the specified ID."; break;
   case DVERR_NOTBUFFERED: msgp = "There is no user buffer for the specified ID."; break;
   case DVERR_HOSTING: msgp = "The object is the host of the session."; break;
   case DVERR_NOTHOSTING: msgp = "The object is not the host of the session."; break;
   case DVERR_INVALIDDEVICE: msgp = "The specified device is invalid."; break;
   case DVERR_RECORDSYSTEMERROR: msgp = "An error in the recording system occurred."; break;
   case DVERR_PLAYBACKSYSTEMERROR: msgp = "An error in the playback system occurred."; break;
   case DVERR_SENDERROR: msgp = "An error occurred while sending data."; break;
   case DVERR_USERCANCEL: msgp = "The user canceled the operation."; break;
   //case DVERR_UNKNOWN: msgp = "An unknown error occurred."; break;
   case DVERR_RUNSETUP: msgp = "The specified audio configuration has not been tested. Call the IDirectPlayVoiceTest::CheckAudioSetup method."; break;
   case DVERR_INCOMPATIBLEVERSION: msgp = "The client connected to a voice session that is incompatible with the host."; break;
   case DVERR_INITIALIZED: msgp = "The Initialize method failed because the object has already been initialized."; break;
   //case DVERR_INVALIDPOINTER: msgp = "The pointer specified is invalid."; break;
   case DVERR_NOTRANSPORT: msgp = "The specified object is not a valid transport."; break;
   case DVERR_NOCALLBACK: msgp = "This operation cannot be performed because no callback function was specified."; break;
   case DVERR_TRANSPORTNOTINIT: msgp = "Specified transport is not yet initialized."; break;
   case DVERR_TRANSPORTNOSESSION: msgp = "Specified transport is valid but is not connected/hosting."; break;
   case DVERR_TRANSPORTNOPLAYER: msgp = "Specified transport is connected/hosting but no local player exists."; break;

   default: msgp = "Unknown Error";
   }
   C_fstr str("DirectPlay: %s\n%s", text, msgp);
   MessageBox(NULL, str, "Fatal Error", MB_OK);
}

//-------------------------------------

