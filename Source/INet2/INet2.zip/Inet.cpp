#include "all.h"
#include "INet_i.h"
#include "resource.h"
#include "timer.h"


const dword DEFAULT_DROP_TIME_OUT = 300000;
//#define DEBUG_ALIGN_BITS_8    //align bitfields to closest byte/word/dword bitdepth

#ifdef _DEBUG

void DP_Fatal(char *text, HRESULT hr);
#define CHECK_DP_RESULT(text, hr) if(FAILED(hr)) DP_Fatal(text, hr);
//#define DEBUG_HANDLER_LOG_MESSAGES  //log messages from handles

#else

#define DP_Fatal(t, hr) {}
#define CHECK_DP_RESULT(text, hr)

#endif

//----------------------------
                              //maximal number of messages in ng queue
                              // if there are more messages to be sent, they're discarded
                              // (automatically lost)
#define MAX_NONGUARANTEED_OUT_QUEUE_MESSAGES 8

#ifdef _DEBUG
static int test_count;
static int test_count1;
#endif

//----------------------------
                              //code used for synchronization tasks
static dword SYNC_CODE = 0x89abcdef;

//----------------------------

static C_str WStringToString(const wchar_t *in_str){

   int len = wcslen(in_str);
   char *buf = new char[len + 1];
   for(int i=0; i<len + 1; i++){
      buf[i] = in_str[i];
   }
   C_str rtn(buf);
   delete[] buf;
   return rtn;
}

//----------------------------

static C_str StringToWString(const char *in_str){

   int len = strlen(in_str);
   wchar_t *buf = new wchar_t[len + 1];
   for(int i=0; i<len + 1; i++){
      buf[i] = in_str[i];
   }
   C_str rtn;
   rtn.Assign((const char*)buf, (len + 1) * 2);
   delete[] buf;
   return rtn;
}

//----------------------------

#define TIME_NUM 32
class C_avg_counter{
   int val[TIME_NUM];
   int time[TIME_NUM];
   int pos;
   bool init;
public:
   C_avg_counter():
      init(false),
      pos(1)
   {
      val[0]=0;
      time[0]=0;
   }
   void Add(int v1, int t1){
      dword last_pos = (pos-1)&(TIME_NUM-1);
      if(t1+time[last_pos] < 20){
         time[last_pos] += t1;
         val[last_pos] += v1;
         return;
      }
      val[pos] = v1;
      time[pos] = t1;
      if(++pos==TIME_NUM) init=true;
      pos &= (TIME_NUM-1);
   }
   float Get() const{
      if(!init) return 0.0f;
      for(int i=0, v(0), t(0); i<TIME_NUM; i++) v += val[i], t += time[i];
      if(t<10) return 0.0f;
      return v*TIME_NUM*1000.0f/TIME_NUM/(float)t;
   }
};

C_timer timer;

//----------------------------
                              //Network class
//----------------------------

class C_unk_base{
public:
   INETMETHOD_(dword,AddRef)() = 0;
   INETMETHOD_(dword,Release)() = 0;
};

//----------------------------

// {F686C6A0-CB6C-11d2-87BD-004F4905FF1A}
static const GUID TEST_GUID =
   { 0xf686c6a0, 0xcb6c, 0x11d2, { 0x87, 0xbd, 0x0, 0x4f, 0x49, 0x5, 0xff, 0x1a } };


//----------------------------
//----------------------------

static const byte bit_mask[] = {0x00, 0x01, 0x03, 0x07, 0x0f, 0x1f, 0x3f, 0x7f, 0xff};


//----------------------------
//----------------------------

                              //used internally
class S_service_provider{
   GUID guid;
public:
   C_str name;
   IN_CONNECTION ctype;

   S_service_provider(){}
   S_service_provider(const S_service_provider &con){ operator =(con); }

   S_service_provider &operator =(const S_service_provider &con){
      guid = con.guid;
      name = con.name;
      ctype = con.ctype;
      return *this;
   }

   inline const GUID *GetGUID() const{ return &guid; }

   void SetGUID(const GUID *g){

      guid = *g;
      if(IsEqualGUID(guid, CLSID_DP8SP_MODEM)){
         ctype = INCON_MODEM;
      }else
      if(IsEqualGUID(guid, CLSID_DP8SP_TCPIP)){
         ctype = INCON_TCPIP;
      }else
      if(IsEqualGUID(guid, CLSID_DP8SP_IPX)){
         ctype = INCON_IPX;
      }else
      if(IsEqualGUID(guid, CLSID_DP8SP_SERIAL)){
         ctype = INCON_SERIAL;
      }else{
         ctype = INCON_UNKNOWN;
      }
   }
};

//----------------------------

class INET_session_address{
   dword ref;

   C_str name;
   dword ping_time;
   C_smart_ptr<IDirectPlay8Address> host_address;
   dword num_players;
   GUID guid_instance;
   dword enum_time;           //helper for enumeration

   INET_session_address():
      ref(1),
      ping_time(0),
      enum_time(0),
      num_players(0)
   {}
   friend class I_net;
public:
   virtual dword INETAPI AddRef(){ return ++ref; }
   virtual dword INETAPI Release(){ if(--ref) return ref; delete this; return 0; }

   INETMETHOD_(const C_str&,GetName)() const{ return name; }
   INETMETHOD_(dword,GetPingTime)() const{ return ping_time; }
   INETMETHOD_(dword,GetNumPlayers)() const{ return num_players; }
};

//----------------------------

class I_net: public I_net_base{
   dword ref;


#define NETFLG_SESSION_CLOSED 1     //session doesn't accept any more players
#define NETFLG_INDICATE_CLOSE 2     //indicate that we should close session in main thread ASAP

                              //DPlay8:
   IDirectPlay8Peer *lpDP8;
   C_smart_ptr<IDirectPlayVoiceServer> lpDVoiceServer;
   C_smart_ptr<IDirectPlayVoiceClient> lpDVoiceClient;
   C_smart_ptr<IDirectPlay8Address> addr_device;
   C_smart_ptr<IDirectPlay8Address> addr_host;
   mutable CRITICAL_SECTION lock_main;

   vector<C_smart_ptr<INET_session_address> > session_list;

   struct S_init_data{
      dword flags;            //combination of ININIT_??? flags
      GUID app_guid;          //unique ID of application
      C_str session_name, player_name;
      IN_CONNECTION connection;  //connection type
      dword max_players;      //max players, 0 if no limit

                              //address settings
      dword serial_baud_rate;
      C_str modem_phone_number;
      C_str ip_host_name;
      C_str port;
      dword drop_time_out;

      INET_INIT::t_log_func *log_func;
      INET_INIT::t_msg_to_string *msg_to_string;

      INET_INIT::E_VOICE_COMPRESSION voice_compression;
   } init_data;

                              //run-time:

   E_NET_STATUS status;
   DPNHANDLE curr_handle;
   dword last_enum_session_time;

                              //incomming message queue
   deque<C_smart_ptr<C_net_in_msg> > in_messages;

                              //connection provider list, built once during initialization
   vector<S_service_provider> provider_list;
   int selected_provider;

   dword host_enum_interval;


   DPNID pid;                 //ID of player created
   dword host_pid;
   dword net_flags;

   C_avg_counter in_count, out_count[INET_MSG_LAST];
   dword last_in_time, last_out_time;

   DPNHANDLE last_sent_ng_msg_handle; //zero = no
                              //handles of all sent messages
   set<DPNHANDLE> sent_msgs;
   DPNHANDLE early_sent_msg;

                              //peer list
   struct S_peer{
      dword pid;
      C_str name;
                              //time when last ng message from this player has arrived
                              // - due to removing older ng messages from particular player
      int last_ng_msg_id;

      int inactivity_count;   //counter for inactivity - used to disconnect dropped players

      S_peer(dword pid1, const C_str &n):
         pid(pid1),
         name(n),
         last_ng_msg_id(0),
         inactivity_count(0)
      {}
      S_peer(const S_peer &pl){ operator =(pl); }
      S_peer &operator =(const S_peer &pl){
         pid = pl.pid;
         name = pl.name;
         last_ng_msg_id = pl.last_ng_msg_id;
         inactivity_count = pl.inactivity_count;
         return *this;
      }
                              //returns true if this time newer than what we have
      bool CheckOrder(int mid){
         int delta = (mid-last_ng_msg_id);
         if(delta<0)
            return false;
         last_ng_msg_id = mid;
         return true;
      }
   };
                              //connected players
   vector<S_peer> peer_list;

//----------------------------

   static const GUID &ConvertCompressionToGUID(INET_INIT::E_VOICE_COMPRESSION vc){

      switch(vc){
      case INET_INIT::VS_1_2: return DPVCTGUID_VR12;
      case INET_INIT::VS_3_2: return DPVCTGUID_SC03;
      case INET_INIT::VS_6_4: return DPVCTGUID_SC06;
      case INET_INIT::VS_8:  return DPVCTGUID_TRUESPEECH;
      case INET_INIT::VS_13: return DPVCTGUID_GSM;
      case INET_INIT::VS_32: return DPVCTGUID_ADPCM;
      case INET_INIT::VS_64: return DPVCTGUID_NONE;
      default: return GUID_NULL;
      }
   }

//----------------------------

   static INET_INIT::E_VOICE_COMPRESSION GetLowerCompression(INET_INIT::E_VOICE_COMPRESSION vc){

      switch(vc){
      case INET_INIT::VS_64: return INET_INIT::VS_32; break;
      case INET_INIT::VS_32: return INET_INIT::VS_13; break;
      case INET_INIT::VS_13: return INET_INIT::VS_8; break;
      case INET_INIT::VS_8: return INET_INIT::VS_6_4; break;
      case INET_INIT::VS_6_4: return INET_INIT::VS_3_2; break;
      case INET_INIT::VS_3_2: return INET_INIT::VS_1_2; break;
      }
      return INET_INIT::VS_NULL;
   }

//----------------------------

   HRESULT HostSessionInternal(dword flags){

      HRESULT hr;

      EnterCriticalSection(&lock_main);

      C_str w_p_name =  StringToWString(init_data.player_name);
      DPN_PLAYER_INFO pi = {
         sizeof(DPN_PLAYER_INFO),
         DPNINFO_NAME,
         (wchar_t*)(const char*)w_p_name,
         NULL, 0,
         0
      };
      hr = lpDP8->SetPeerInfo(&pi,
         NULL,
         NULL,
         DPNSETPEERINFO_SYNC);

      CHECK_DP_RESULT("SetPeerInfo", hr);
      if(SUCCEEDED(hr)){

         {


            DPN_APPLICATION_DESC ad;
            memset(&ad, 0, sizeof(ad));
            ad.dwSize = sizeof(ad);
            ad.dwFlags = 0;
            if(init_data.flags&ININIT_MIGRATE_HOST){
               ad.dwFlags |= DPNSESSION_MIGRATE_HOST;
            }
            ad.guidApplication = init_data.app_guid;
            ad.dwMaxPlayers = init_data.max_players;
            C_str w_s_name = StringToWString(init_data.session_name);
            ad.pwszSessionName = (wchar_t*)(const char*)w_s_name;

                              //pid assigned by DPN_MSGID_CREATE_PLAYER message
            assert(!pid);
            assert(!host_pid);
            NET_LOG1("Hosting session...\n");
            hr = lpDP8->Host(&ad,
                              //device address
               (IDirectPlay8Address**)&addr_device, 1,
                              //2x reserved
               NULL, NULL,
                              //player context
               NULL,
                              //flags
               0);
            CHECK_DP_RESULT("Host", hr);
            if(SUCCEEDED(hr)){
               assert(pid);
               assert(!(net_flags&NETFLG_INDICATE_CLOSE));
               status = INET_ST_CONNECTED;
               NET_LOG1("Hosting successful.\n");

               if(flags&INHOST_INIT_VOICE_CHAT){
                              //init voice-chat stuff
                  assert(!lpDVoiceServer);
                  IDirectPlayVoiceServer *vs;
                  hr = CoCreateInstance(CLSID_DirectPlayVoiceServer, NULL, CLSCTX_INPROC_SERVER,
                     IID_IDirectPlayVoiceServer, (void**)&vs);
                  if(SUCCEEDED(hr)){
                     hr = vs->Initialize(lpDP8, VoiceHandlerThunk, this, NULL, 0);
                     if(SUCCEEDED(hr)){

                        DVSESSIONDESC sd;
                        memset(&sd, 0, sizeof(sd));
                        sd.dwSize = sizeof(sd);
                        sd.dwFlags = 0;
                        sd.dwSessionType = DVSESSIONTYPE_PEER;
                        sd.guidCT = DPVCTGUID_SC06;
                        INET_INIT::E_VOICE_COMPRESSION vc = init_data.voice_compression;
                        sd.guidCT = ConvertCompressionToGUID(vc);
                        sd.dwBufferQuality = DVBUFFERQUALITY_DEFAULT;
                        sd.dwBufferAggressiveness = DVBUFFERAGGRESSIVENESS_DEFAULT;
                        hr = vs->StartSession(&sd, 0);
                        while(FAILED(hr)){
                                 //try lower quality
                           vc = GetLowerCompression(vc);
                           if(vc==INET_INIT::VS_NULL)
                              break;
                           sd.guidCT = ConvertCompressionToGUID(vc);
                           hr = vs->StartSession(&sd, 0);
                        }

                        if(SUCCEEDED(hr)){
                           lpDVoiceServer = vs;
                        }
                     }
                     vs->Release();
                  }
               }
               CreateSyncThread();
            }else{
               NET_LOG1("Hosting failed.\n");
            }
         }
      }
      LeaveCriticalSection(&lock_main);
      return hr;
   }

//----------------------------
// Private function for joining DPlay session specified by GUID.
   HRESULT JoinSessionInternal(CPINET_session_address sa){

      assert(lpDP8);
      assert(status==INET_ST_UNCONNECTED);
      HRESULT hr;

      EnterCriticalSection(&lock_main);

      {
         status = INET_ST_CONNECTING;

         C_str w_p_name =  StringToWString(init_data.player_name);
         DPN_PLAYER_INFO pi = {
            sizeof(DPN_PLAYER_INFO),
            DPNINFO_NAME,
            (wchar_t*)(const char*)w_p_name,
            NULL, 0,
            0
         };
         hr = lpDP8->SetPeerInfo(&pi,
            NULL,
            NULL,
            DPNSETPEERINFO_SYNC);
         CHECK_DP_RESULT("SetPeerInfo", hr);

         if(SUCCEEDED(hr)){
            DPN_APPLICATION_DESC ad;
            memset(&ad, 0, sizeof(ad));
            ad.dwSize = sizeof(ad);
            ad.guidApplication = init_data.app_guid;

            const IDirectPlay8Address *dp8_addr = sa->host_address;
            DPNHANDLE handle;
            NET_LOG1("Connecting...\n");
            hr = lpDP8->Connect(&ad,
               (IDirectPlay8Address*)dp8_addr,
               addr_device,
                              //reserved
               NULL, NULL,
                              //connection data
               (const char*)init_data.player_name, init_data.player_name.Size() + 1,
                              //player context
               NULL,
                              //async context
               this,
                              //async handle
               &handle,
                              //flags
               0
               );
            CHECK_DP_RESULT("Connect", hr);
            if(SUCCEEDED(hr)){
               curr_handle = handle;
               NET_LOG1(C_fstr("Assigned handle: 0x%.8x.\n", curr_handle));
            }
            if(FAILED(hr)){
               status = INET_ST_UNCONNECTED;
            }
         }
      }
      LeaveCriticalSection(&lock_main);

      return hr;
   }

//----------------------------
// Collect list of all connection providers. This operation is done only once during
// the life-time of the interface.
   void EnumServiceProviders(){

                              //enum providers only once
      if(provider_list.size())
         return;

      static const struct S_provider_info{
         const char *name;
         const GUID *guid;
      } provider_info[] = {
         {"Modem connection", &CLSID_DP8SP_MODEM},
         {"TCP/IP connection", &CLSID_DP8SP_TCPIP},
         {"IPX connection", &CLSID_DP8SP_IPX},
         {"Serial cable connection", &CLSID_DP8SP_SERIAL},
      };

      provider_list.assign(sizeof(provider_info) / sizeof(S_provider_info), S_service_provider());

      for(int i=sizeof(provider_info) / sizeof(S_provider_info); i--; ){
         provider_list[i].name = provider_info[i].name;
         provider_list[i].SetGUID(provider_info[i].guid);
      }
   }

//----------------------------

   HRESULT SelectServiceProvider(int indx){

      assert(indx < (int)provider_list.size());
      selected_provider = indx;

      const GUID *sp_guid = provider_list[selected_provider].GetGUID();

      HRESULT hr;

      if(1){
         DPN_SP_CAPS sp_caps;
         memset(&sp_caps, 0, sizeof(sp_caps));
         sp_caps.dwSize = sizeof(sp_caps);
         hr = lpDP8->GetSPCaps(sp_guid, &sp_caps, 0);
         //CHECK_DP_RESULT("GetSPCaps", hr);
         if(FAILED(hr))
            return hr;
         //assert(sp_caps.dwFlags&DPNSPCAPS_SUPPORTSALLADAPTERS);
         //host_enum_interval = sp_caps.dwDefaultEnumRetryInterval * 2;
         host_enum_interval = 10000;
      }else{
         host_enum_interval = 10000;
      }

      hr = addr_device->SetSP(sp_guid);
      CHECK_DP_RESULT("SetSP", hr);

      hr = addr_host->SetSP(sp_guid);
      CHECK_DP_RESULT("SetSP", hr);

      switch(provider_list[selected_provider].ctype){

      case INCON_IPX:
         break;

      case INCON_TCPIP:
         {
                              //device address:

                              //host address: host name, port
            if(init_data.ip_host_name.Size()){
               C_str ws = StringToWString(init_data.ip_host_name);
               hr = addr_host->AddComponent(DPNA_KEY_HOSTNAME, (const char*)ws, (init_data.ip_host_name.Size()+1) * sizeof(wchar_t), DPNA_DATATYPE_STRING);
               CHECK_DP_RESULT("AddComponent", hr);
               if(FAILED(hr)) break;
            }
            if(init_data.port.Size()){
               dword port = atoi(init_data.port);
               hr = addr_host->AddComponent(DPNA_KEY_PORT, &port, sizeof(dword), DPNA_DATATYPE_DWORD);
               CHECK_DP_RESULT("AddComponent", hr);
               if(FAILED(hr)) break;
            }
         }
         break;

      case INCON_MODEM:
         {                    
                              //device address:
            DPN_SERVICE_PROVIDER_INFO *dpi = NULL;
            dword buf_want = 0, num_items = 0;
            hr = lpDP8->EnumServiceProviders(&CLSID_DP8SP_MODEM, NULL,
               dpi, &buf_want, &num_items, 0);
            if(hr!=DPNERR_BUFFERTOOSMALL){
               hr = DPNERR_GENERIC;
               break;
            }
            dpi = (DPN_SERVICE_PROVIDER_INFO*)new byte[buf_want];
            hr = lpDP8->EnumServiceProviders(&CLSID_DP8SP_MODEM, NULL,
               dpi, &buf_want, &num_items, 0);
            assert(hr!=DPNERR_BUFFERTOOSMALL);
            if(FAILED(hr)){
               delete[] (byte*)dpi;
               break;
            }
            GUID modem_guid = dpi[0].guid;
            delete[] (byte*)dpi;

            hr = addr_host->AddComponent(DPNA_KEY_DEVICE, &modem_guid, sizeof(GUID), DPNA_DATATYPE_GUID);
            CHECK_DP_RESULT("AddComponent", hr);
            if(FAILED(hr)) break;


                              //host address: phone number
            if(init_data.modem_phone_number.Size()){
               C_str ws = StringToWString(init_data.modem_phone_number);
               hr = addr_host->AddComponent(DPNA_KEY_PHONENUMBER, (const char*)ws, (init_data.modem_phone_number.Size()+1) * sizeof(wchar_t), DPNA_DATATYPE_STRING);
               CHECK_DP_RESULT("AddComponent", hr);
               if(FAILED(hr)) break;
            }
         }
         break;

      case INCON_SERIAL:
         {
                              //device address: baud rate, flow control, parity, stop bits
            hr = addr_device->AddComponent(DPNA_KEY_BAUD, &init_data.serial_baud_rate, sizeof(dword), DPNA_DATATYPE_DWORD);
            CHECK_DP_RESULT("AddComponent", hr);
            if(FAILED(hr)) break;

            assert(0);        //build rest of components & test
         }
         break;
      }

#if defined _DEBUG && 0
      {                       //debug - get string from address
         char buf[512];
         dword sz = sizeof(buf);
         hr = addr_device->GetURLA(buf, &sz);
         CHECK_DP_RESULT("GetURLA", hr);
         sz = sizeof(buf);
         hr = addr_host->GetURLA(buf, &sz);
         CHECK_DP_RESULT("GetURLA", hr);
      }
#endif

      return hr;
   }

//----------------------------
// Enumerate sessions in current connection.
   HRESULT EnumHosts(){

      assert(lpDP8);

      HRESULT hr;

      EnterCriticalSection(&lock_main);

      {

         DPN_APPLICATION_DESC ad;
         memset(&ad, 0, sizeof(ad));
         ad.dwSize = sizeof(ad);
         ad.dwFlags = 0;
         ad.guidApplication = init_data.app_guid;
         assert(status==INET_ST_UNCONNECTED);

         DPNHANDLE handle;
         NET_LOG1(C_fstr("Starting enumeration...\n"));
         hr = lpDP8->EnumHosts(&ad,
                                 //host address
            addr_host,
                                 //device address
            addr_device,
                                 //enum data
            NULL, 0,
                                 //enum count
            INFINITE,
                                 //retry count
            0,
                                 //time out
            INFINITE,
                                 //user context
            NULL,
            &handle,
                                 //flags
            0);
         CHECK_DP_RESULT("EnumHosts", hr);

         if(SUCCEEDED(hr)){
            status = INET_ST_ENUMERATING_SESSIONS;
            curr_handle = handle;
            NET_LOG1(C_fstr("Assigned handle: 0x%.8x.\n", curr_handle));
         }
      }
      LeaveCriticalSection(&lock_main);

      return hr;
   }

//----------------------------
// Get data associated with peer. Caller must delete the returned buffer
// by calling delete[] (byte*)buf.
   DPN_PLAYER_INFO *GetPeerData(dword pid) const{
            
      dword buf_size = sizeof(DPN_PLAYER_INFO);
      DPN_PLAYER_INFO *pi = (DPN_PLAYER_INFO*)new byte[buf_size];
      pi->dwSize = buf_size;
      HRESULT hr = lpDP8->GetPeerInfo(pid, pi, &buf_size, 0);
      if(hr==DPNERR_BUFFERTOOSMALL){
         delete[] (byte*)pi;
         pi = (DPN_PLAYER_INFO*)new byte[buf_size];
         pi->dwSize = sizeof(DPN_PLAYER_INFO);

         hr = lpDP8->GetPeerInfo(pid, pi, &buf_size, 0);
         CHECK_DP_RESULT("GetPeerInfo", hr);
      }else{
         CHECK_DP_RESULT("GetPeerInfo", hr);
      }
      return pi;
   }

//----------------------------

   void AddSystemMessage(void *data, dword len){

      assert(len >= sizeof(S_msg_header));
                              //clear message header
      memset(data, 0, sizeof(S_msg_header));
                              //create system message (pid = 0)
      PC_net_in_msg sys_msg = new C_net_in_msg(NULL, NULL, E_BUFFERTYPE_NEW_ALLOCATED,
         init_data.log_func, init_data.msg_to_string, init_data.player_name,
         data, len, 0);
                              //save for later processing
      in_messages.push_back(sys_msg);
      sys_msg->Release();
   }

 //----------------------------

   HRESULT MessageHandler(dword dwMessageType, void *pMessage){

      HRESULT rtn = S_OK;

      EnterCriticalSection(&lock_main);

      switch(dwMessageType){

      case DPN_MSGID_CREATE_PLAYER:
         {
            DPNMSG_CREATE_PLAYER *msg = (DPNMSG_CREATE_PLAYER*)pMessage;

            DPN_PLAYER_INFO *pi = GetPeerData(msg->dpnidPlayer);

#ifdef DEBUG_HANDLER_LOG_MESSAGES
            {
               C_str player_flags;
               if(pi->dwPlayerFlags&DPNPLAYER_LOCAL) player_flags += "local";
               if(pi->dwPlayerFlags&DPNPLAYER_HOST) player_flags += " host";
               if(!player_flags.Size()) player_flags = "0";
               NET_LOG1(C_fstr("> Created player: pid = 0x%.8x, player name: '%s', flags: %s.\n",
                  msg->dpnidPlayer, (const char*)WStringToString(pi->pwszName),
                  (const char*)player_flags));
            }
#endif

            if(pi->dwPlayerFlags&DPNPLAYER_LOCAL){
                              //this is our player, so save its PID
               assert(!pid);
               pid = msg->dpnidPlayer;
               if(pi->dwPlayerFlags&DPNPLAYER_HOST){
                              //we're the host!
                  host_pid = pid;
               }
            }else{
               AddPeerToList(msg->dpnidPlayer, WStringToString(pi->pwszName));

                              //generate system message
#pragma pack(push,1)
               struct S_player_data: public S_msg_header{
                  word msg_id;
                  dword pid;
               } *player_data = (S_player_data*)new byte[sizeof(S_player_data)];
#pragma pack(pop)
               player_data->msg_id = INET_SYSMSG_PLAYER_CREATED;
               player_data->pid = msg->dpnidPlayer;
               AddSystemMessage(player_data, sizeof(S_player_data));
            }
            delete[] (byte*)pi;
         }
         break;

      case DPN_MSGID_DESTROY_PLAYER:
         {
            DPNMSG_DESTROY_PLAYER *msg = (DPNMSG_DESTROY_PLAYER*)pMessage;
            DPN_PLAYER_INFO *pi = GetPeerData(msg->dpnidPlayer);

#ifdef DEBUG_HANDLER_LOG_MESSAGES
            {
               const char *reason = "unknown";
               switch(msg->dwReason){
               case DPNDESTROYPLAYERREASON_NORMAL: reason = "normal disconnect"; break;
               case DPNDESTROYPLAYERREASON_CONNECTIONLOST: reason = "connection lost"; break;
               case DPNDESTROYPLAYERREASON_SESSIONTERMINATED: reason = "session terminated"; break;
               case DPNDESTROYPLAYERREASON_HOSTDESTROYEDPLAYER: reason = "host destroyed player"; break;
               }
               NET_LOG1(C_fstr("> Destroyed player: 0x%.8x, reason: %s.\n",
                  msg->dpnidPlayer, reason)); 
            }
#endif   //DEBUG_HANDLER_LOG_MESSAGES
            if(pi->dwPlayerFlags&DPNPLAYER_LOCAL){
               assert(msg->dpnidPlayer==pid);
               pid = 0;

                              //generate system message
#pragma pack(push,1)
               struct S_terminate_data: public S_msg_header{
                  word msg_id;
               } *terminate_data = (S_terminate_data*)new byte[sizeof(S_terminate_data)];
#pragma pack(pop)
               terminate_data->msg_id = INET_SYSMSG_SESSION_OVER;
               AddSystemMessage(terminate_data, sizeof(S_terminate_data));
            }else{
                              //generate system message
#pragma pack(push,1)
               struct S_player_data: public S_msg_header{
                  word msg_id;
                  dword pid;
                  char name[256];
               } *player_data = (S_player_data*)new byte[sizeof(S_player_data)];
#pragma pack(pop)
               player_data->msg_id = INET_SYSMSG_PLAYER_DESTROYED;
               player_data->pid = msg->dpnidPlayer;
               C_str plr_name;
               GetPlayerName(player_data->pid, plr_name);
               strncpy(player_data->name, plr_name, sizeof(player_data->name));
               AddSystemMessage(player_data, sizeof(S_player_data) - sizeof(player_data->name) + strlen(player_data->name) + 1);

               DeletePeerFromList(msg->dpnidPlayer);
            }
            if(host_pid==msg->dpnidPlayer)
               host_pid = 0;

            delete[] (byte*)pi;
         }
         break;

      case DPN_MSGID_INDICATE_CONNECT:
         {
            DPNMSG_INDICATE_CONNECT *msg = (DPNMSG_INDICATE_CONNECT*)pMessage;
#ifdef DEBUG_HANDLER_LOG_MESSAGES
            {
               NET_LOG1(C_fstr("> Attempt to connect from peer: '%s'.\n", msg->pvUserConnectData));
            }
#endif
                              //check if our session os open
            if(net_flags&NETFLG_SESSION_CLOSED){
#ifdef DEBUG_HANDLER_LOG_MESSAGES
               NET_LOG1(C_fstr("> Session is closed, refusing connection.\n"));
#endif
               rtn = -1;
            }else{
                              //send to peer our (host) pid
               assert(host_pid==pid);
               msg->pvReplyData = new byte[sizeof(dword)];
               *(dword*)msg->pvReplyData = pid;
               msg->dwReplyDataSize = sizeof(dword);
               msg->pvReplyContext = (void*)E_BUFFERTYPE_NEW_ALLOCATED;
            }
         }
         break;

      case DPN_MSGID_INDICATED_CONNECT_ABORTED:
         {
            //DPNMSG_INDICATED_CONNECT_ABORTED *msg = (DPNMSG_INDICATED_CONNECT_ABORTED*)pMessage;
#ifdef DEBUG_HANDLER_LOG_MESSAGES
            NET_LOG1(C_fstr("> Connecting aborted.\n"));
#endif
         }
         break;

      case DPN_MSGID_CONNECT_COMPLETE:
         {
            PDPNMSG_CONNECT_COMPLETE msg = (PDPNMSG_CONNECT_COMPLETE)pMessage;
            assert(status==INET_ST_CONNECTING);
            assert(!(net_flags&NETFLG_INDICATE_CLOSE));
            if(SUCCEEDED(msg->hResultCode)){
               status = INET_ST_CONNECTED;
               CreateSyncThread();
                              //we should have local player created by now
               assert(pid);
                              //determine the host's pid
               assert(!host_pid);
               assert(msg->dwApplicationReplyDataSize==sizeof(dword));
               host_pid = *(dword*)msg->pvApplicationReplyData;
            }else{
               status = INET_ST_UNCONNECTED;
            }
            curr_handle = NULL;

#ifdef DEBUG_HANDLER_LOG_MESSAGES
            {
               const char *st = "unknown";
               switch(msg->hResultCode){
               case DPN_OK: st = "OK"; break;
               case DPNERR_HOSTREJECTEDCONNECTION: st = "host rejected connection"; break;
               case DPNERR_INVALIDAPPLICATION: st = "invalid application"; break;
               case DPNERR_INVALIDDEVICEADDRESS: st = "invalid device address"; break;
               case DPNERR_INVALIDFLAGS: st = "invalid flags"; break;
               case DPNERR_INVALIDHOSTADDRESS: st = "invalid host address"; break;
               case DPNERR_NOCONNECTION: st = "no connection"; break;
               case DPNERR_NOTHOST: st = "no host"; break;
               case DPNERR_SESSIONFULL: st = "session full"; break;
               }
               NET_LOG1(C_fstr("> Connecting complete, status: %s, host is: 0x%.8x.\n",
                  st, host_pid));
            }
#endif
         }
         break;

      case DPN_MSGID_RECEIVE:
         {
            DPNMSG_RECEIVE *msg = (DPNMSG_RECEIVE*)pMessage;
                              //check which kind of message it is
            if(msg->dwReceiveDataSize == sizeof(SYNC_CODE)){
                           //check out who answered
               for(int i=peer_list.size(); i--; ){
                  if(peer_list[i].pid==msg->dpnidSender){
                           //reset sync counter for this player
                     peer_list[i].inactivity_count = 0;
                     break;
                  }
               }
               assert(i!=-1);
            }else{
                              //we may be able to receive just before being connected
               //assert(status==INET_ST_CONNECTED);
#ifdef DEBUG_HANDLER_LOG_MESSAGES
               {
                  const char *name = "<unknown>";
                  for(int i=peer_list.size(); i--; ){
                     if(peer_list[i].pid==msg->dpnidSender){
                        name = peer_list[i].name;
                        break;
                     }
                  }
                  const S_msg_header &hdr = *(S_msg_header*)msg->pReceiveData;
                  NET_LOG1(C_fstr("> Message received from '%s', MSGID = %i, size = %i bytes (%s).\n",
                     name, hdr.msg_id, msg->dwReceiveDataSize, hdr.guaranteed ? "g" : "ng"));
               }
#endif
                              //construct message from this
               PC_net_in_msg in_msg = new C_net_in_msg(lpDP8, msg->hBufferHandle,
                  E_BUFFERTYPE_DPLAY,
                  init_data.log_func, init_data.msg_to_string, init_data.player_name,
                  msg->pReceiveData, msg->dwReceiveDataSize,
                  msg->dpnidSender);
                              //save for later processing
               in_messages.push_back(in_msg);
               in_msg->Release();
            }
            rtn = DPNSUCCESS_PENDING;
         }
         break;

      case DPN_MSGID_RETURN_BUFFER:
         {
            DPNMSG_RETURN_BUFFER *msg = (DPNMSG_RETURN_BUFFER*)pMessage;
#ifdef DEBUG_HANDLER_LOG_MESSAGES
            {
               const char *type = "unknown";
               switch((E_BUFFER_TYPE)(dword)(msg->pvUserContext)){
               case E_BUFFERTYPE_NEW_ALLOCATED: type = "allocated by new byte[]"; break;
               }
               NET_LOG1(C_fstr("> Buffer returned: 0x%.8x, type: %s.\n",
                  msg->pvBuffer, type));
            }
#endif
            switch((E_BUFFER_TYPE)(dword)(msg->pvUserContext)){
            case E_BUFFERTYPE_NEW_ALLOCATED:
               delete[] (byte*)msg->pvBuffer;
               break;
            }
         }
         break;

      case DPN_MSGID_ASYNC_OP_COMPLETE:
         {
            DPNMSG_ASYNC_OP_COMPLETE *msg = (DPNMSG_ASYNC_OP_COMPLETE*)pMessage;
#ifdef DEBUG_HANDLER_LOG_MESSAGES
            {
               NET_LOG1(C_fstr("> Async op completed: handle = 0x%.8x, curr_handle = 0x%.8x.\n", msg->hAsyncOp, curr_handle));
            }
#endif
            if(msg->hAsyncOp == curr_handle)
               curr_handle = NULL;
         }
         break;

      case DPN_MSGID_ENUM_HOSTS_QUERY:
         {
#ifdef DEBUG_HANDLER_LOG_MESSAGES
            DPNMSG_ENUM_HOSTS_QUERY *msg = (DPNMSG_ENUM_HOSTS_QUERY*)pMessage;
            {
               char buf[256];
               dword buf_size = sizeof(buf);
               msg->pAddressSender->GetURLA(buf, &buf_size);
               NET_LOG1(C_fstr("> Enum host query from: %s.\n", buf));
            }
#endif
            if(net_flags&NETFLG_SESSION_CLOSED){
#ifdef DEBUG_HANDLER_LOG_MESSAGES
               NET_LOG1(C_fstr("> Session is closed, refusing enumeration.\n"));
#endif
               rtn = -1;
            }
         }
         break;

      case DPN_MSGID_ENUM_HOSTS_RESPONSE:
         {
            DPNMSG_ENUM_HOSTS_RESPONSE *msg = (DPNMSG_ENUM_HOSTS_RESPONSE*)pMessage;
#ifdef DEBUG_HANDLER_LOG_MESSAGES
            {
               C_str name = WStringToString(msg->pApplicationDescription->pwszSessionName);
               NET_LOG1(C_fstr("> Enum host response from: '%s', latency: %i ms.\n",
                  (const char*)name, msg->dwRoundTripLatencyMS));
            }
#endif
                              //put into the list, if not yet,
                              // or update parameters
            PINET_session_address sa = NULL;
            for(int i=session_list.size(); i--; ){
               if(session_list[i]->guid_instance == msg->pApplicationDescription->guidInstance){
                  sa = session_list[i];
                  break;
               }
            }
            if(!sa){
               sa = new INET_session_address;
               sa->guid_instance = msg->pApplicationDescription->guidInstance;
               session_list.push_back(sa);
               sa->Release();
            }
            sa->host_address = msg->pAddressSender;
            sa->ping_time = msg->dwRoundTripLatencyMS;
            sa->num_players = msg->pApplicationDescription->dwCurrentPlayers;
            sa->name = WStringToString(msg->pApplicationDescription->pwszSessionName);
            sa->enum_time = timeGetTime();
         }
         break;

      case DPN_MSGID_HOST_MIGRATE:
         {
            DPNMSG_HOST_MIGRATE *msg = (DPNMSG_HOST_MIGRATE*)pMessage;
            assert(status==INET_ST_CONNECTED);
            host_pid = msg->dpnidNewHost;
#ifdef DEBUG_HANDLER_LOG_MESSAGES
            {
               NET_LOG1(C_fstr("> Host migrated, new host is: 0x%.8x%s.\n",
                  msg->dpnidNewHost, host_pid==pid ? " - that means we're the new host" : ""));
            }
#endif            
            {
                              //generate system message
#pragma pack(push,1)
               struct S_migrate_data: public S_msg_header{
                  word msg_id;
                  dword new_host_pid;
               } *migrate_data = (S_migrate_data*)new byte[sizeof(S_migrate_data)];
#pragma pack(pop)
               migrate_data->msg_id = INET_SYSMSG_HOST_MIGRATED;
               migrate_data->new_host_pid = host_pid;
               AddSystemMessage(migrate_data, sizeof(S_migrate_data));
            }
         }
         break;

      case DPN_MSGID_SEND_COMPLETE:
         {
            DPNMSG_SEND_COMPLETE *msg = (DPNMSG_SEND_COMPLETE*)pMessage;

            if(last_sent_ng_msg_handle==msg->hAsyncOp){
               assert(0);     //test it!
               last_sent_ng_msg_handle = 0;
            }
                           //erase this handle from our list
            assert(!early_sent_msg);
            set<DPNHANDLE>::iterator it = sent_msgs.find(msg->hAsyncOp);
            if(it!=sent_msgs.end())
               sent_msgs.erase(it);
            else
               early_sent_msg = msg->hAsyncOp;

                              //release resources
            assert(msg->pvUserContext);
            PS_memory_buffer mem_buf = (PS_memory_buffer)msg->pvUserContext;
            mem_buf->Release();
#ifdef DEBUG_HANDLER_LOG_MESSAGES
            {
               NET_LOG1(C_fstr("> Send complete: handle = 0x%.8x, in time: %i ms.\n", msg->hAsyncOp, msg->dwSendTime));
            }
#endif
         }
         break;

      case DPN_MSGID_TERMINATE_SESSION:
         {
            //DPNMSG_TERMINATE_SESSION *msg = (DPNMSG_TERMINATE_SESSION*)pMessage;
#ifdef DEBUG_HANDLER_LOG_MESSAGES
            {
               NET_LOG1(C_fstr("> Session terminated by the host.\n"));
            }
#endif
            assert(status==INET_ST_CONNECTED);
            if(sync_handler_exit){
                           //indicate host's handler to exit
               bool ok;
               ok = SetEvent(sync_handler_exit);
               assert(ok);
               while(sync_handler_exit)
                  Sleep(10);
            }
            status = INET_ST_UNCONNECTED;
         }
         break;

      default:
         assert(0);
      }

      LeaveCriticalSection(&lock_main);

      return rtn;
   }

//----------------------------

   static HRESULT WINAPI MessageHandlerThunk(void *pvUserContext, dword dwMessageType, void *pMessage){

      return ((I_net*)pvUserContext)->MessageHandler(dwMessageType, pMessage);
   }
   
//----------------------------

   HRESULT VoiceHandler(dword dwMessageType, void *lpMessage){

      HRESULT rtn = S_OK;

      return rtn;
   }

//----------------------------

   static HRESULT WINAPI VoiceHandlerThunk(void *pvUserContext, dword dwMessageType, void *lpMessage){

      return ((I_net*)pvUserContext)->VoiceHandler(dwMessageType, lpMessage);
   }

//----------------------------
// Handler for sync tasks (detection of dropped players, etc).
   HANDLE sync_handler_exit;
   C_smart_ptr<S_memory_buffer> sync_mem_buf;

   void SyncHandler(){

      HRESULT hr;
      assert(sync_handler_exit);
      const dword wait_time = init_data.drop_time_out / 5;
      while(true){
                              //the time-out here specifies how often we send sync messages
         dword wst = WaitForSingleObject(sync_handler_exit, wait_time);
         switch(wst){
         case WAIT_OBJECT_0:
            {
                              //signal for us to exit
               NET_LOG1("> SyncHandler: asked to exit, terminating thread.\n");
                              //destroy host's handler
               hr = CloseHandle(sync_handler_exit);
               assert(SUCCEEDED(hr));
               sync_handler_exit = NULL;
               ExitThread(0);
               return;
            }
            break;

         case WAIT_TIMEOUT:
            {
                              //do actual synchronization
               EnterCriticalSection(&lock_main);

               if(IsHost()){
                              //check who's inactive for a long time
                  for(int i=peer_list.size(); i--; ){
                     S_peer &p = peer_list[i];
                     p.inactivity_count += wait_time;
                     if(p.inactivity_count >= (int)init_data.drop_time_out){
                        hr = lpDP8->DestroyPeer(p.pid, NULL, 0, 0);
                        assert(SUCCEEDED(hr));
                     }
                  }
               }else{
                  for(int i=peer_list.size(); i--; ){
                     S_peer &p = peer_list[i];
                     if(p.pid==host_pid){
                        p.inactivity_count += wait_time;
                        if(p.inactivity_count >= (int)init_data.drop_time_out){
                              //host dropped, indicate closing
                           assert(status==INET_ST_CONNECTED);
                           net_flags |= NETFLG_INDICATE_CLOSE;

                           NET_LOG1("> SyncHandler: host dropped, request close.\n");

                           LeaveCriticalSection(&lock_main);
                           WaitForSingleObject(sync_handler_exit, INFINITE);
                           hr = CloseHandle(sync_handler_exit);
                           assert(SUCCEEDED(hr));
                           sync_handler_exit = NULL;

                           ExitThread(0);
                           return;
                        }
                        break;
                     }
                  }
               }
                              //send small piece of data
                              //host sends to all, clients send to host only
               dword pid_to = IsHost() ? 0 : host_pid;
               Send1(sync_mem_buf, pid_to, INET_MSG_G);

               LeaveCriticalSection(&lock_main);
            }
            break;

         default:
                              //unknown state, better exit
            assert(0);
            ExitThread(0);
            return;
         }
      }
   }

   static dword WINAPI SyncHandler_thunk(void *c){

      ((I_net*)c)->SyncHandler();
      return 0;
   }

//----------------------------

   void CreateSyncThread(){

      assert(!sync_handler_exit);
      sync_handler_exit = CreateEvent(NULL, true, false, NULL);

      dword hh_tid;
      HANDLE h = CreateThread(NULL, 0, SyncHandler_thunk, this, 0, &hh_tid);
      assert(h);
      bool b;
      b = CloseHandle(h);
      assert(b);
   }

//----------------------------

   void DestroyDP(){

      if(lpDP8){
         lpDP8->Release();
         lpDP8 = NULL;
      }
      addr_device = NULL;
      addr_host = NULL;
   }

//----------------------------

   HRESULT CreateDP(){

      if(!lpDP8){
                              //create DP peer object
         HRESULT hr = CoCreateInstance(CLSID_DirectPlay8Peer, NULL, CLSCTX_INPROC_SERVER,
            IID_IDirectPlay8Peer, (void**)&lpDP8);
         CHECK_DP_RESULT("DirectPlay8Create", hr);
         if(SUCCEEDED(hr)){
                              //create addresses
            hr = CoCreateInstance(CLSID_DirectPlay8Address, NULL, CLSCTX_INPROC_SERVER,
               IID_IDirectPlay8Address, (void**)&addr_device);
            CHECK_DP_RESULT("CoCreateInstance", hr);
            if(SUCCEEDED(hr)){
               hr = CoCreateInstance(CLSID_DirectPlay8Address, NULL, CLSCTX_INPROC_SERVER,
                  IID_IDirectPlay8Address, (void**)&addr_host);
               CHECK_DP_RESULT("CoCreateInstance", hr);
            }
            if(SUCCEEDED(hr)){

               hr = lpDP8->Initialize(this, MessageHandlerThunk, 0);
               CHECK_DP_RESULT("Initialize", hr);
            }
         }
         return hr;
      }
      return DPN_OK;
   }

//----------------------------
// Send specified data to target player, or group. The data buffer is passed directly to
// DPlay for transmittion, and deleted during DPN_MSGID_SEND_COMPLETE message.
   bool Send1(PS_memory_buffer mem_buf, dword id_to, E_INET_MESSAGE_TYPE send_type, dword insend_flags = 0){

      if(!mem_buf->GetSize())
         return true;
      if(!pid)
         return false;

      dword send_flags = DPNSEND_NOLOOPBACK | DPNSEND_NOCOPY;
      switch(send_type){
      case INET_MSG_NG:
         {
                              //can drop non-quaranteed, if outgoing buffer overflowed
            dword num_msg, num_bytes;
            for(int i=peer_list.size(); i--; ){
               HRESULT hr = lpDP8->GetSendQueueInfo(peer_list[i].pid, &num_msg, &num_bytes, 0);
               if(SUCCEEDED(hr)){
                  if(num_msg >= MAX_NONGUARANTEED_OUT_QUEUE_MESSAGES){
                     NET_LOG1("Outgoing queue overflowed, silently dropping message.\n");
                     return true;
                  }
               }
            }
         }
         break;

      case INET_MSG_G:
         send_flags |= DPNSEND_GUARANTEED;
         break;
      }

      mem_buf->AddRef();
      DPN_BUFFER_DESC buf = {mem_buf->GetSize(), (byte*)mem_buf->GetData()};
      DPNHANDLE msg_handle;
      HRESULT hr = lpDP8->SendTo(id_to,
         &buf, 1,
         0,                   //time-out
         mem_buf,             //async context
         &msg_handle,
         send_flags);

      CHECK_DP_RESULT("SendTo", hr);

      if(FAILED(hr)){
         mem_buf->Release();
      }

#ifdef DEBUG_HANDLER_LOG_MESSAGES
      NET_LOG1(C_fstr("> SendTo: obtained async handle 0x%x\n", msg_handle));
#endif

                              //save message handle for later use
      if(early_sent_msg==msg_handle)
         early_sent_msg = 0;
      else
         sent_msgs.insert(msg_handle);

                              //cancel all previous non-guaranteed messages which haven't left yet
      if((insend_flags&INSEND_CANCELOLDER) && (send_type==INET_MSG_NG)){
                              //cancel last non-guaranteed message
         if(last_sent_ng_msg_handle){
            hr = lpDP8->CancelAsyncOperation(last_sent_ng_msg_handle, DPNCANCEL_SEND);
            CHECK_DP_RESULT("CancelAsyncOperation", hr);
         }
         last_sent_ng_msg_handle = msg_handle;
      }

      return SUCCEEDED(hr);
   }

//----------------------------
// Add network peer to list.
   bool AddPeerToList(dword pid, const C_str &name){

      for(int i=peer_list.size(); i--; )
         if(peer_list[i].pid==pid)
            break;
      assert(i==-1);
      peer_list.push_back(S_peer(pid, name));
      return true;
   }

//----------------------------

   bool DeletePeerFromList(dword pid){

      for(int i=peer_list.size(); i--; )
         if(peer_list[i].pid==pid)
            break;
      assert(i!=-1);
      peer_list.erase(peer_list.begin()+i);
      return true;
   }

//----------------------------
//----------------------------
public:
   I_net():
      ref(1),
      status(INET_ST_UNINITIALIZED),
      curr_handle(NULL),
      lpDP8(NULL),
      sync_handler_exit(NULL),
      pid(0),
      net_flags(0),
      early_sent_msg(0),
      last_sent_ng_msg_handle(0),
      selected_provider(-1),
      host_pid(0)
   {
      sync_mem_buf = new S_memory_buffer(&SYNC_CODE, sizeof(SYNC_CODE));
      sync_mem_buf->Release();

      memset(&init_data.app_guid, 0, sizeof(init_data.app_guid));
      last_out_time = last_in_time = timer.GetTime();
      InitializeCriticalSection(&lock_main);
   }

//----------------------------

   ~I_net(){

      in_messages.clear();
      Close();
      in_messages.clear();
      DestroyDP();
      DeleteCriticalSection(&lock_main);
   }

//----------------------------

   bool Init(INET_INIT *ci);

//----------------------------

   virtual bool INETAPI IsHost() const{

      return (pid && host_pid==pid);
   }

//----------------------------

   virtual E_NET_STATUS INETAPI GetStatus() const{

      return status;
   }

//----------------------------

   virtual dword INETAPI GetPID() const{

      return pid;
   }

//----------------------------

   dword INETAPI GetHostPID() const{
      return host_pid;
   }

//----------------------------

   virtual bool INETAPI GetPlayerName(dword plr_id, C_str &name) const{

      bool rtn = true;
      EnterCriticalSection(&lock_main);

      if(plr_id==pid){
         name = init_data.player_name;
         /*
         strncpy(buf, init_data.player_name, buf_size);
         if(buf_size==init_data.player_name.Size())
            buf[buf_size-1] = 0;
            */
      }else{
         for(int i=peer_list.size(); i--; )
            if(peer_list[i].pid==plr_id)
               break;
         if(i!=-1){
            name = peer_list[i].name;
            /*
            strncpy(buf, peer_list[i].name, buf_size);
            if(buf_size==peer_list[i].name.Size())
               buf[buf_size-1] = 0;
               */
         }else
            rtn = false;
      }

      LeaveCriticalSection(&lock_main);
      return rtn;
   }

//----------------------------

   virtual bool INETAPI Send(PC_net_out_msg, dword id_to = 0, dword flags = 0);

//----------------------------

   virtual void INETAPI ProcessMessages(INET_MESSAGECALLBACK *plr_proc, dword context, dword flags){

      assert(plr_proc);

      if(net_flags&NETFLG_INDICATE_CLOSE)
         Close();

      EnterCriticalSection(&lock_main);

      AddRef();               //we may get released during user callback

      dword total_size = 0;

      bool loop = true;
                              //process all messages in incoming queue
      while(loop && in_messages.size()){
                              //get message header
         C_smart_ptr<C_net_in_msg> in_msg = in_messages.front();
         in_messages.pop_front();

         const S_msg_header &m_hdr = in_msg->GetHeader();

         dword pid_sender = in_msg->GetSenderPID();
         if(!pid_sender){
            NET_LOG1("Processing system message.\n");
            LeaveCriticalSection(&lock_main);
            loop = plr_proc(this, in_msg, context);
            EnterCriticalSection(&lock_main);
         }else{
            bool process = true;
            if(!m_hdr.guaranteed && (flags&INPROCESS_SKIPOLDER)){
               process = false;
                                 //find the owner
               for(int i=peer_list.size(); i--; )
                  if(peer_list[i].pid==pid_sender)
                     break;
               if(i!=-1){

                              //compare time stamps, discard older messages
                  process = peer_list[i].CheckOrder(m_hdr.msg_id);
               }
            }
            if(process){
#ifdef _DEBUG
               {
                  const char *name = "<unknown>";
                  for(int i=peer_list.size(); i--; ){
                     if(peer_list[i].pid==in_msg->GetSenderPID()){
                        name = peer_list[i].name;
                        break;
                     }
                  }
                  const S_msg_header &hdr = in_msg->GetHeader();
                  NET_LOG1(C_fstr("Processing message from '%s', MSGID = %i, size = %i bits (%s).\n",
                     name, hdr.msg_id, in_msg->GetSize(), hdr.guaranteed ? "g" : "ng"));
               }
#endif
               LeaveCriticalSection(&lock_main);
               loop = plr_proc(this, in_msg, context);
               EnterCriticalSection(&lock_main);
            }
            total_size += (in_msg->GetSize() + 7) / 8;
         }
      }
                              //stats
      if(total_size){
         dword curr_time = timer.GetTime();
         in_count.Add(total_size, curr_time - last_in_time);
         last_in_time = curr_time;
      }

      LeaveCriticalSection(&lock_main);

      Release();              //don't do anything after this - we may be destroyed by now
   }

//----------------------------

   virtual PC_net_out_msg INETAPI CreateOutMsg(){

      return new C_net_out_msg(init_data.log_func, init_data.msg_to_string);
   }

//----------------------------

   void AddDPConnectionStats(DPNID conn_pid, I3D_stats_net &st){

      DPN_CONNECTION_INFO ci;
      memset(&ci, 0, sizeof(DPN_CONNECTION_INFO));
      ci.dwSize = sizeof(DPN_CONNECTION_INFO);
      HRESULT hr = lpDP8->GetConnectionInfo(conn_pid, &ci, 0);
      if(FAILED(hr))
         return;
      {
         st.dp.dwRoundTripLatencyMS = ci.dwRoundTripLatencyMS;
         st.dp.dwThroughputBPS = ci.dwThroughputBPS;
         st.dp.dwPeakThroughputBPS = ci.dwPeakThroughputBPS;
         st.dp.dwBytesSentGuaranteed = ci.dwBytesSentGuaranteed;
         st.dp.dwPacketsSentGuaranteed = ci.dwPacketsSentGuaranteed;
         st.dp.dwBytesSentNonGuaranteed = ci.dwBytesSentNonGuaranteed;
         st.dp.dwPacketsSentNonGuaranteed = ci.dwPacketsSentNonGuaranteed;
         st.dp.dwBytesRetried = ci.dwBytesRetried;
         st.dp.dwPacketsRetried = ci.dwPacketsRetried;
         st.dp.dwBytesDropped = ci.dwBytesDropped;
         st.dp.dwPacketsDropped = ci.dwPacketsDropped;
         st.dp.dwMessagesTransmittedHighPriority = ci.dwMessagesTransmittedHighPriority;
         st.dp.dwMessagesTimedOutHighPriority = ci.dwMessagesTimedOutHighPriority;
         st.dp.dwMessagesTransmittedNormalPriority = ci.dwMessagesTransmittedNormalPriority;
         st.dp.dwMessagesTimedOutNormalPriority = ci.dwMessagesTimedOutNormalPriority;
         st.dp.dwMessagesTransmittedLowPriority = ci.dwMessagesTransmittedLowPriority;
         st.dp.dwMessagesTimedOutLowPriority = ci.dwMessagesTimedOutLowPriority;
         st.dp.dwBytesReceivedGuaranteed = ci.dwBytesReceivedGuaranteed;
         st.dp.dwPacketsReceivedGuaranteed = ci.dwPacketsReceivedGuaranteed;
         st.dp.dwBytesReceivedNonGuaranteed = ci.dwBytesReceivedNonGuaranteed;
         st.dp.dwPacketsReceivedNonGuaranteed = ci.dwPacketsReceivedNonGuaranteed;
         st.dp.dwMessagesReceived = ci.dwMessagesReceived;
      }
   }

//----------------------------

   void GetDPStats(I3D_stats_net &st){

                              //zero dp part of structure
      memset(&st.dp, 0, sizeof(I3D_stats_net::S_direct_play));

      //const dword conn_pid = (!IsHost()) ? host_pid : DPNID_ALL_PLAYERS_GROUP;
      //AddDPConnectionStats(DPID conn_id, I3D_stats_net &st);

                              //collect info from all connections
      const S_peer *p_peer_list = &peer_list.front();
      for(dword i = peer_list.size(); i--; ){

         const S_peer &pp = p_peer_list[i];
         if(pp.pid == pid)
            continue;
         AddDPConnectionStats(pp.pid, st);
      }
   }

//----------------------------

   //virtual void INETAPI GetStats(dword *in, dword *out_g, dword *out_ng)
   virtual void INETAPI GetStats(I3D_stats_net &ret_st){

      dword curr_time = timer.GetTime();

      if(last_out_time!=curr_time){
         for(int i=0; i<INET_MSG_LAST; i++)
            out_count[i].Add(0, curr_time - last_out_time);
         last_out_time = curr_time;
      }
      if(curr_time!=last_in_time){
         in_count.Add(0, curr_time - last_in_time);
         last_in_time = curr_time;
      }

      ret_st.in = in_count.Get();
      ret_st.out_ng = out_count[INET_MSG_NG].Get();
      ret_st.out_g = out_count[INET_MSG_G].Get();
                              //collect direct play stats
      GetDPStats(ret_st);
   }

//----------------------------

   bool EnumSessionsInternal(){

      Close();
      switch(status){

      case INET_ST_ENUMERATING_SESSIONS:
         Close();
                              //flow...
      case INET_ST_UNCONNECTED:
         HRESULT hr = EnumHosts();
         if(SUCCEEDED(hr)){
            last_enum_session_time = timeGetTime();
            return true;
         }
      }
      return false;
   }

//----------------------------
                              //how long we keep sessions in list, if it's not re-inited
#define ENUM_SESSION_AGE (host_enum_interval*3)

   virtual bool INETAPI EnumSessions(PINET_session_address *sap, dword *num_sessions){

      if(status!=INET_ST_ENUMERATING_SESSIONS)
         EnumSessionsInternal();
      else{
         dword time_delta = timeGetTime() - last_enum_session_time;
         if(time_delta >= host_enum_interval){
            vector<C_smart_ptr<INET_session_address> > save_session_list = session_list;
            EnumSessionsInternal();
                              //join lists - older and (possible) new sessions
            EnterCriticalSection(&lock_main);
            for(int i=save_session_list.size(); i--; ){
               INET_session_address *sess = save_session_list[i];

                              //don't keep too old sessions
               int session_age = last_enum_session_time - sess->enum_time;
               if(session_age < (int)ENUM_SESSION_AGE){
                  for(int j=session_list.size(); j--; ){
                     if(session_list[j]->guid_instance == sess->guid_instance)
                        break;
                  }
                  if(j==-1)
                     session_list.push_back(sess);
               }
            }
            LeaveCriticalSection(&lock_main);
         }
      }

      if(status!=INET_ST_ENUMERATING_SESSIONS){
         *num_sessions = 0;
         return false;
      }
      if(*num_sessions < session_list.size()){
         *num_sessions = session_list.size();
         return false;
      }
      for(dword i=0; i<session_list.size(); i++){
         sap[i] = session_list[i];
         sap[i]->AddRef();
      }
      *num_sessions = session_list.size();
      return true;
   }

//----------------------------

   virtual bool INETAPI GetPlayers(dword *pids, dword *num_players) const{

      if(status!=INET_ST_CONNECTED){
         *num_players = 0;
         return false;
      }
      if(*num_players < peer_list.size()){
         *num_players = peer_list.size();
         return false;
      }
      for(dword i=0; i<peer_list.size(); i++){
         pids[i] = peer_list[i].pid;
      }
      *num_players = peer_list.size();
      return true;

   }

//----------------------------

   virtual bool INETAPI HostSession(dword flags){

      assert(lpDP8 && !pid);

      switch(status){
      case INET_ST_UNCONNECTED:
         break;
      case INET_ST_CONNECTING:
      case INET_ST_ENUMERATING_SESSIONS:
      case INET_ST_CONNECTED:
         Close();
         break;
      default: 
         assert(0);
      }

      HRESULT hr = HostSessionInternal(flags);
      if(FAILED(hr)){
         DestroyDP();
         CreateDP();
      }
      return (SUCCEEDED(hr));
   }

//----------------------------

   virtual bool INETAPI JoinSession(CPINET_session_address sa){

      assert(lpDP8 && !pid);
      const_cast<PINET_session_address>(sa)->AddRef();

      switch(status){
      case INET_ST_UNCONNECTED:
         break;
      case INET_ST_CONNECTING:
      case INET_ST_ENUMERATING_SESSIONS:
      case INET_ST_CONNECTED:
         Close();
         break;
      default: 
         assert(0);
      }
      HRESULT hr = JoinSessionInternal(sa);
      if(FAILED(hr)){
         DestroyDP();
         CreateDP();
      }
      const_cast<PINET_session_address>(sa)->Release();
      return (SUCCEEDED(hr));
   }

//----------------------------

   virtual bool INETAPI InitVoice(void *focus_hwnd, struct IDirectSound8 *dsound){

      assert(!lpDVoiceClient);
      if(lpDVoiceClient)
         return false;

      IDirectPlayVoiceClient *vc;
      HRESULT hr = CoCreateInstance(CLSID_DirectPlayVoiceClient, NULL, 
         CLSCTX_INPROC_SERVER, IID_IDirectPlayVoiceClient, (void**)&vc);
      if(SUCCEEDED(hr)){
         static const dword want_msgs[] = {
            DVMSGID_INPUTLEVEL,
            DVMSGID_OUTPUTLEVEL,
            DVMSGID_PLAYEROUTPUTLEVEL,
         };
         hr = vc->Initialize(lpDP8, VoiceHandlerThunk, this, (dword*)want_msgs, sizeof(want_msgs)/sizeof(dword));
         if(SUCCEEDED(hr)){
            DVSOUNDDEVICECONFIG sndcfg;
            memset(&sndcfg, 0, sizeof(sndcfg));
            sndcfg.dwSize = sizeof(sndcfg);
            sndcfg.dwFlags = DVSOUNDCONFIG_AUTOSELECT;
            sndcfg.guidPlaybackDevice = DSDEVID_DefaultVoicePlayback;
            sndcfg.lpdsPlaybackDevice = dsound;
            sndcfg.guidCaptureDevice = DSDEVID_DefaultVoiceCapture;
            sndcfg.lpdsCaptureDevice = NULL;
            sndcfg.hwndAppWindow = (HWND)focus_hwnd;
            sndcfg.lpdsMainBuffer = NULL;
            sndcfg.dwMainBufferFlags = 0;
            sndcfg.dwMainBufferPriority = 0;

            DVCLIENTCONFIG clndcfg;
            memset(&clndcfg, 0, sizeof(clndcfg));
            clndcfg.dwSize = sizeof(clndcfg);
            clndcfg.dwFlags = DVCLIENTCONFIG_AUTORECORDVOLUME | DVCLIENTCONFIG_AUTOVOICEACTIVATED;
            clndcfg.lRecordVolume = DVRECORDVOLUME_LAST;
            clndcfg.lPlaybackVolume = DVPLAYBACKVOLUME_DEFAULT;
            clndcfg.dwThreshold = DVTHRESHOLD_UNUSED;
            clndcfg.dwBufferQuality = DVBUFFERQUALITY_DEFAULT;
            clndcfg.dwBufferAggressiveness = DVBUFFERAGGRESSIVENESS_DEFAULT;
            clndcfg.dwNotifyPeriod = 0;
         
            hr = vc->Connect(&sndcfg, &clndcfg, DVFLAGS_SYNC);
            if(SUCCEEDED(hr)){
               DVID tid = DVID_ALLPLAYERS;
               hr = vc->SetTransmitTargets(&tid, 1, 0);
               CHECK_DP_RESULT("SetTransmitTargets", hr);
               lpDVoiceClient = vc;
            }
         }
         vc->Release();
      }
      return (lpDVoiceClient!=NULL);
   }

//----------------------------

   virtual void INETAPI CloseVoice(){

      if(lpDVoiceClient){
         lpDVoiceClient->Disconnect(DVFLAGS_SYNC);
         lpDVoiceClient = NULL;
      }
   }

//----------------------------

   virtual bool INETAPI TestVoice(void *hwnd, bool force_test){

      IDirectPlayVoiceTest *voice_test;

      bool ret = false;
      HRESULT hr;
                              //create the IDirectPlayVoiceTest Object
      hr = CoCreateInstance(CLSID_DirectPlayVoiceTest, NULL, CLSCTX_INPROC_SERVER, IID_IDirectPlayVoiceTest, (void**)&voice_test);
      if(SUCCEEDED(hr)){
         bool run_test = true;
         if(!force_test){
            hr = voice_test->CheckAudioSetup(&DSDEVID_DefaultVoicePlayback, &DSDEVID_DefaultVoiceCapture, 
               NULL, DVFLAGS_QUERYONLY);
            if(hr!=DVERR_RUNSETUP)
               run_test = false;
            else
               ret = true;
         }
         if(run_test){
            hr = voice_test->CheckAudioSetup(&DSDEVID_DefaultVoicePlayback, &DSDEVID_DefaultVoiceCapture, 
               (HWND)hwnd, DVFLAGS_ALLOWBACK);
            ret = (SUCCEEDED(hr));
         }
         voice_test->Release();
      }
      return ret;
   }

//----------------------------

   virtual bool INETAPI Close(){

      bool rtn = true;
      HRESULT hr;

      switch(status){

      case INET_ST_UNINITIALIZED:
      case INET_ST_UNCONNECTED:
         rtn = false;
         break;

      case INET_ST_ENUMERATING_SESSIONS:
         {
            EnterCriticalSection(&lock_main);

            NET_LOG1("Cancelling host enumeration.\n");
            if(curr_handle){
               hr = lpDP8->CancelAsyncOperation(curr_handle, 0);
               CHECK_DP_RESULT("CancelAsyncOperation", hr);
               curr_handle = NULL;
            }
            status = INET_ST_UNCONNECTED;
            session_list.clear();

            LeaveCriticalSection(&lock_main);
         }
         break;

      case INET_ST_CONNECTING:
         {
            EnterCriticalSection(&lock_main);

            NET_LOG1("Cancelling attempt to connect.\n");
            assert(curr_handle);
            hr = lpDP8->CancelAsyncOperation(curr_handle, 0);
            CHECK_DP_RESULT("CancelAsyncOperation", hr);
            curr_handle = NULL;
            status = INET_ST_UNCONNECTED;

            LeaveCriticalSection(&lock_main);
         }
         break;

      case INET_ST_CONNECTED:
         {
            NET_LOG1("Disconnecting...\n");
            assert(!curr_handle);
            net_flags &= ~NETFLG_INDICATE_CLOSE;

            if(lpDP8){
               HRESULT hr;

               if(sync_handler_exit){
                              //indicate host's handler to exit
                  bool ok;
                  ok = SetEvent(sync_handler_exit);
                  assert(ok);
                  while(sync_handler_exit)
                     Sleep(10);
               }

               EnterCriticalSection(&lock_main);

               CloseVoice();
                              //uninit voice chat
               if(lpDVoiceServer){
                  lpDVoiceServer->StopSession(DVFLAGS_NOHOSTMIGRATE);
                  lpDVoiceServer = NULL;
               }
                              //cancel all previous non-guaranteed messages which haven't left yet
               if(last_sent_ng_msg_handle){
                  NET_LOG1("Canceling last non-guar. message.\n");
                  hr = lpDP8->CancelAsyncOperation(last_sent_ng_msg_handle, DPNCANCEL_SEND);
                  CHECK_DP_RESULT("CancelAsyncOperation", hr);
                  last_sent_ng_msg_handle = 0;
               }
               LeaveCriticalSection(&lock_main);

               if(sent_msgs.size()){
                              //give it some time to send out all pending messages
                  for(int i=40; i--; ){
                     EnterCriticalSection(&lock_main);
                     dword num_msg, num_bytes;
                     for(int j=peer_list.size(); j--; ){
                        hr = lpDP8->GetSendQueueInfo(peer_list[j].pid, &num_msg, &num_bytes, 0);
                        if(SUCCEEDED(hr) && (num_msg || num_bytes)){
                           break;
                        
                        }
                     }
                     LeaveCriticalSection(&lock_main);
                     if(j==-1){
                        break;
                     }
                     Sleep(10);
                  }
                  if(i==-1){
                              //messages pending, cancel them now
                     EnterCriticalSection(&lock_main);

                              //operate on own copy, they may be released
                     set<DPNHANDLE> save_hnds = sent_msgs;
                     set<DPNHANDLE>::iterator it;
                     for(it=save_hnds.begin(); it!=save_hnds.end(); it++){
                        DPNHANDLE h = (*it);
                        lpDP8->CancelAsyncOperation(h, 0);
                     }
                     LeaveCriticalSection(&lock_main);

                     NET_LOG1("Pending messages!!!\n");
                  }
               }
                              //pid destroyed by DPN_MSGID_DESTROY_PLAYER message
               NET_LOG1("Closing DP interface...\n");
               hr = lpDP8->Close(0);
               CHECK_DP_RESULT("Close", hr);
               assert(!pid);
               assert(!host_pid);
               in_messages.clear();
                              //clear handles just now, thay may be erased during call to Close() above
               EnterCriticalSection(&lock_main);
               sent_msgs.clear();
               early_sent_msg = 0;
               LeaveCriticalSection(&lock_main);

               hr = lpDP8->Initialize(this, MessageHandlerThunk, 0);
               CHECK_DP_RESULT("Initialize", hr);
            }
            assert(!peer_list.size());

            NET_LOG1("Disconnected.\n");

            status = INET_ST_UNCONNECTED;
         }
         break;

      default:
         assert(0);
      }

      return rtn;
   }

//----------------------------

   INETMETHOD_(bool,SetOpen)(bool b){

      if(b)
         net_flags &= ~NETFLG_SESSION_CLOSED;
      else
         net_flags |= NETFLG_SESSION_CLOSED;
      return true;
   }

//----------------------------

   virtual dword INETAPI AddRef(){ return ++ref; }
   virtual dword INETAPI Release(){ if(--ref) return ref; delete this; return 0; }

//----------------------------

   INETMETHOD_(void,Log)(const char *cp){

      EnterCriticalSection(&lock_main);
      NET_LOG1("//");
      NET_LOG1(cp);
      NET_LOG1("\n");
      LeaveCriticalSection(&lock_main);
   }

//----------------------------

   INETMETHOD_(IDirectPlay8Peer*,GetDPInterface)() const{ return lpDP8; }
};

//----------------------------

bool I_net::Init(INET_INIT *ci){

   if(ci->app_guid){
      init_data.app_guid = *(LPGUID)ci->app_guid;
   }else{
      init_data.app_guid = TEST_GUID;
   }
   HRESULT hr;
   hr = CoInitialize(NULL);
   CHECK_DP_RESULT("CoInitialize", hr);
   if(FAILED(hr))
      return false;

   {
      hr = CreateDP();
      if(FAILED(hr))
         goto fail;
   }

   status = INET_ST_UNCONNECTED;

   if(SUCCEEDED(hr)){
      init_data.session_name = ci->session_name;
      init_data.player_name = ci->player_name;
      init_data.flags = ci->flags;
      init_data.log_func = ci->log_func;
      init_data.msg_to_string = ci->msg_to_string;
      init_data.max_players = ci->max_players;
      init_data.modem_phone_number = ci->modem_phone_number;
      init_data.ip_host_name = ci->ip_host_name;
      init_data.port = ci->port;
      init_data.voice_compression = ci->voice_compression;
      init_data.drop_time_out = ci->drop_timeout ? ci->drop_timeout : DEFAULT_DROP_TIME_OUT;
                              //check if forced connection type
      if(ci->connection != INCON_NULL){
         EnumServiceProviders();
                           //try to find the forced connection
         for(int i=provider_list.size(); i--; ){
            if(provider_list[i].ctype == ci->connection)
               break;
         }

         if(i!=-1){        //use this
            hr = SelectServiceProvider(i);
            if(FAILED(hr))
               goto fail;
         }else{
                              //unrecognized provider
            return false;
         }
      }
      return true;
   }
fail:
   Close();
   return false;
}

//----------------------------

bool INETAPI I_net::Send(PC_net_out_msg out_msg, dword id_to, dword insend_flags){

   if(status!=INET_ST_CONNECTED)
      return false;

   if(net_flags&NETFLG_INDICATE_CLOSE){
      Close();
      return false;
   }

   EnterCriticalSection(&lock_main);

   bool ret = true;

   if(status==INET_ST_CONNECTED){
      int i;

      dword curr_time = timer.GetTime();

      for(i=0; i<INET_MSG_LAST; i++){
         out_count[i].Add((out_msg->GetSize(i) + 7) / 8, curr_time - last_out_time);

         PS_memory_buffer mem_buf = out_msg->GetBuffer(i, pid);
         if(!mem_buf)
            continue;

#ifdef _DEBUG
         const S_msg_header &hdr = *(const S_msg_header*)mem_buf->GetData();
         NET_LOG1(C_fstr("Message sent: MSGID = %i, size = %i bytes, (%s)\n--------------\n",
            hdr.msg_id, mem_buf->GetSize(), hdr.guaranteed ? "g" : "ng"));
#endif
         if(!Send1(mem_buf, id_to, (E_INET_MESSAGE_TYPE)i, insend_flags))
            ret = false;

         mem_buf->Release();
      }
      last_out_time = curr_time;
   }else
      ret = false;

   out_msg->Clear();

   LeaveCriticalSection(&lock_main);
   return ret;
}

//----------------------------
//----------------------------
                              //creation

PI_net InetCreate(PINET_INIT init_data){

   PI_net net = new I_net;

   bool b = net->Init(init_data);
   if(!b){
      net->Release();
      net = NULL;
   }
   return net;
}

//----------------------------
//----------------------------

