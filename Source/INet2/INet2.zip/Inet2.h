/*--------------------------------------------------------
   Copyright (c) Lonely Cat Games  All rights reserved.

   File: Inet.h
   Content: Insanity network support
--------------------------------------------------------*/
#ifndef __INET2_H
#define __INET2_H


#pragma comment (lib,"inet2_thunk")


#include <rules.h>

#define INETAPI __stdcall
#define INETMETHOD_(type,method) virtual type INETAPI method

//----------------------------
                              //connection type
enum IN_CONNECTION{
   INCON_NULL,
   INCON_TCPIP,               //internet TCP/IP
   INCON_IPX,                 //IPX
   INCON_MODEM,               //modem
   INCON_SERIAL,              //serial cable
   INCON_UNKNOWN,
};

enum{                         //initialization flags
   ININIT_CLIENTSERVER = 2,   //use client-server mode
   ININIT_MIGRATE_HOST = 0x40,//allow host migration
};

enum{                         //send flags
   INSEND_CANCELOLDER = 2,    //cancel older non-guaranteed messages which haven't left yet
};
                              
enum{                         //ProcessMessages flags
   INPROCESS_SKIPOLDER = 1,   //skips older non-guaranteed messages if newer message from the same player has already been processed
};

enum{
   INHOST_INIT_VOICE_CHAT = 1,//initialize voice chat server when hosting session
};

                              //initialization structure
struct INET_INIT{
   dword flags;               //combination of ININIT_??? flags
   const void *app_guid;      //unique ID of application
   const char *session_name, *player_name;   
   IN_CONNECTION connection;  //connection type
   dword max_players;         //max players, 0 if no limit

                              //host address:
   const char *modem_phone_number;
   const char *ip_host_name;
   const char *port;
   //dword serial_baud_rate;
   int drop_timeout;          //timeout after which we discover a player is dropped
   
                              //callback: log output
   typedef void __stdcall t_log_func(const char*);
   t_log_func *log_func;

                              //callback: translate message ID into name
   typedef const char *__stdcall t_msg_to_string(word);
   t_msg_to_string *msg_to_string;

   enum E_VOICE_COMPRESSION{
      VS_NULL,
      VS_1_2,
      VS_3_2,
      VS_6_4,
      VS_8,
      VS_13,
      VS_32,
      VS_64,
   } voice_compression;
};

typedef INET_INIT *PINET_INIT;

//----------------------------
typedef class I_net *PI_net;
typedef class C_net_out_msg *PC_net_out_msg;
typedef const C_net_out_msg *CPC_net_out_msg;
typedef class C_net_in_msg *PC_net_in_msg;
typedef const C_net_in_msg *CPC_net_in_msg;

typedef class I_net_client *PI_net_client;
typedef class I_net_server *PI_net_server;

                              //incomming message processing callback
typedef bool INETAPI INET_MESSAGECALLBACK(PI_net, PC_net_in_msg, dword context);

                              //
typedef bool INETAPI INET_MESSAGECALLBACK_CLIENT(PI_net_client, PC_net_in_msg, dword context);
typedef bool INETAPI INET_MESSAGECALLBACK_SERVER(PI_net_server, PC_net_in_msg, dword context);


//----------------------------// stats
typedef struct{
   dword in;
   dword out_g;
   dword out_ng;

   struct S_direct_play{
      dword dwRoundTripLatencyMS;
      dword dwThroughputBPS;
      dword dwPeakThroughputBPS;
      dword dwBytesSentGuaranteed;
      dword dwPacketsSentGuaranteed;
      dword dwBytesSentNonGuaranteed;
      dword dwPacketsSentNonGuaranteed;
      dword dwBytesRetried;
      dword dwPacketsRetried;
      dword dwBytesDropped;
      dword dwPacketsDropped;
      dword dwMessagesTransmittedHighPriority;
      dword dwMessagesTimedOutHighPriority;
      dword dwMessagesTransmittedNormalPriority;
      dword dwMessagesTimedOutNormalPriority;
      dword dwMessagesTransmittedLowPriority;
      dword dwMessagesTimedOutLowPriority;
      dword dwBytesReceivedGuaranteed;
      dword dwPacketsReceivedGuaranteed;
      dword dwBytesReceivedNonGuaranteed;
      dword dwPacketsReceivedNonGuaranteed;
      dword dwMessagesReceived;
   }dp;

} I3D_stats_net, *PI3D_stats_net;



//----------------------------
// Session address.
//----------------------------
#ifndef INET_FULL
class INET_session_address{
public:
   INETMETHOD_(dword,AddRef)() = 0;
   INETMETHOD_(dword,Release)() = 0;

//----------------------------
// Get name of session, which this interface describes. This is the same as session name
// of player hosting the enumerated session.
   INETMETHOD_(const class C_str&,GetName)() const = 0;

//----------------------------
// Get ping time from this machine to the machine on which the session resides.
   INETMETHOD_(dword,GetPingTime)() const = 0;

//----------------------------
// Get number of players currently connected to the session.
   INETMETHOD_(dword,GetNumPlayers)() const = 0;
};
#endif

typedef class INET_session_address *PINET_session_address;
typedef const INET_session_address *CPINET_session_address;

//----------------------------
                              //network driver status - use GetStatus to determine this
enum E_NET_STATUS{
                              //uninitialized state - internal
   INET_ST_UNINITIALIZED = 0,

                              //unconnected - connection either not established,
                              // lost, or closed
   INET_ST_UNCONNECTED = 1,

                              //currently connecting - when connecting is finished, the state
                              // automatically (non-synchronized) switches to
                              // INET_ST_CONNECTED or INET_ST_UNCONNECTED
                              //use Close to stop connection attempt
   INET_ST_CONNECTING = 2,

                              //currently enumerating sessions - in this state it is allowed
                              // to use GetSessions method
                              //use Close to stop the enumeration, or try to connect
   INET_ST_ENUMERATING_SESSIONS = 3,

                              //connected - in this state it is possible to send messages
                              //use Close to disconnect
   INET_ST_CONNECTED = 4,
};

//----------------------------

#ifndef INET_FULL
                              //network interface class
class I_net{
public:
   INETMETHOD_(dword,AddRef)() = 0;
   INETMETHOD_(dword,Release)() = 0;
                              //interfaces:

//----------------------------
// Determine if this interface is session master.
   INETMETHOD_(bool,IsHost)() const = 0;

//----------------------------
// Return the current status of interface.
   INETMETHOD_(E_NET_STATUS,GetStatus)() const = 0;

//----------------------------
// Get name of player identified by 'plr_id'.
   INETMETHOD_(bool,GetPlayerName)(dword plr_id, C_str &name) const = 0;

//----------------------------
// Get our peer ID. Valid only in connected state, otherwise 0 is returned.
   INETMETHOD_(dword,GetPID)() const = 0;

//----------------------------
// Get host's ID. Valid only in connected state, otherwise 0 is returned.
   INETMETHOD_(dword,GetHostPID)() const = 0;

//----------------------------
// Send message in a queue. This func may be used only in connected state.
   INETMETHOD_(bool,Send)(PC_net_out_msg, dword id_to = 0, dword flags = 0) = 0;

//----------------------------
// Receive and process messages.
   INETMETHOD_(void,ProcessMessages)(INET_MESSAGECALLBACK *plr_proc,
      dword context = 0, dword flags = 0) = 0;

//----------------------------
// Create outgoing message.
   INETMETHOD_(PC_net_out_msg,CreateOutMsg)() = 0;

                              //sessions
//----------------------------
// Get list of enumerated sessions.
// In: addrs = buffer to fill to, num_sessions is size of the buffer.
// Returns: true if buffer was filled, false if buffer is too small.
//    *num_sessions contains number of sessions after return.
// Note: after successful retrieving of sessions, you must call Release for all active session.
   INETMETHOD_(bool,EnumSessions)(PINET_session_address *addrs, dword *num_sessions) = 0;

//----------------------------
// Get list of connected players - not including local player.
// In: pids = buffer to fill to, num_players is size of the buffer.
// Returns: true if buffer was filled, false if buffer is too small.
//    *num_players contains number of active players after return.
   INETMETHOD_(bool,GetPlayers)(dword *pids, dword *num_players) const = 0;

//----------------------------
// Start (host) session.
   INETMETHOD_(bool,HostSession)(dword flags = 0) = 0;

//----------------------------
// Join session. The session is identified by address, which is obtained by GetSessions method.
   INETMETHOD_(bool,JoinSession)(CPINET_session_address) = 0;

//----------------------------
// Initialize voice chat session. This may be done after connected to a session.
// Parameters:
//    'focus_hwnd' - HWND of focus window
//    'dsound' - DirectSound interface used for sound playback
// Note:
//    voice sound buffer is created automatically
   INETMETHOD_(bool,InitVoice)(void *focus_hwnd, struct IDirectSound8 *dsound = NULL) = 0;

//----------------------------
// Close voice session previously initialized by InitVoice.
// Note: this is done automatically when Close() is called to close connection.
   INETMETHOD_(void,CloseVoice)() = 0;

//----------------------------
// Test voice chat. This function invokes Windows dialog which allows testing and configuration
// of voice chat.
   INETMETHOD_(bool,TestVoice)(void *hwnd, bool force_test = false) = 0;

//----------------------------
// Close - terminate current action - it may be session enumeration, attempt to connection,
// or already set connection.
   INETMETHOD_(bool,Close)() = 0;

//----------------------------
// Set status of the session to open or closed. If the session is closed, no more players
// may join the session, and it is no more enumerated to possible clients.
   INETMETHOD_(bool,SetOpen)(bool) = 0;

                              //debugging
   //INETMETHOD_(void,GetStats)(dword *in, dword *out_g, dword *out_ng) = 0;
   INETMETHOD_(void,GetStats)(I3D_stats_net &ret_st) = 0;
   INETMETHOD_(void,Log)(const char*) = 0;

//----------------------------
// Get pointer to DPlay interface.
   INETMETHOD_(struct IDirectPlay8Peer*,GetDPInterface)() const = 0;
};


//----------------------------
//----------------------------
// C-S interface
//----------------------------
//----------------------------

class I_net_client{
public:
   INETMETHOD_(dword,AddRef)() = 0;
   INETMETHOD_(dword,Release)() = 0;
                              //interfaces:
//----------------------------
// Send message in a queue. This func may be used only in connected state.
   INETMETHOD_(bool,Send)(PC_net_out_msg, dword flags = 0) = 0;

//----------------------------
// Receive and process messages.
   INETMETHOD_(void,ProcessMessages)(INET_MESSAGECALLBACK *plr_proc,
      dword context = 0, dword flags = 0) = 0;

//----------------------------
// Create outgoing message.
   INETMETHOD_(PC_net_out_msg,CreateOutMsg)() = 0;

                              //sessions
//----------------------------
// Get list of enumerated sessions.
// In: addrs = buffer to fill to, num_sessions is size of the buffer.
// Returns: true if buffer was filled, false if buffer is too small.
//    *num_sessions contains number of sessions after return.
// Note: after successful retrieving of sessions, you must call Release for all active session.
   INETMETHOD_(bool,EnumSessions)(PINET_session_address *addrs, dword *num_sessions) = 0;

//----------------------------
// Join session. The session is identified by address, which is obtained by GetSessions method.
   INETMETHOD_(bool,JoinSession)(CPINET_session_address) = 0;

//----------------------------
// Close - terminate current action - it may be session enumeration, attempt to connection,
// or already set connection.
   INETMETHOD_(bool,Close)() = 0;
};

//----------------------------
//----------------------------

class I_net_server{
public:
   INETMETHOD_(dword,AddRef)() = 0;
   INETMETHOD_(dword,Release)() = 0;
                              //interfaces:
//----------------------------
// Send message in a queue. This func may be used only in connected state.
   INETMETHOD_(bool,SendTo)(PC_net_out_msg, dword id_to = 0, dword flags = 0) = 0;

//----------------------------
// Receive and process messages.
   INETMETHOD_(void,ProcessMessages)(INET_MESSAGECALLBACK *plr_proc,
      dword context = 0, dword flags = 0) = 0;

//----------------------------
// Create outgoing message.
   INETMETHOD_(PC_net_out_msg,CreateOutMsg)() = 0;

                              //sessions
//----------------------------
// Start (host) session.
   INETMETHOD_(bool,HostSession)(dword flags = 0) = 0;

//----------------------------
// Close - terminate current action - it may be session enumeration, attempt to connection,
// or already set connection.
   INETMETHOD_(bool,Close)() = 0;

};

//----------------------------
//----------------------------

                              //outgoing message
class C_net_out_msg2{
public:
   INETMETHOD_(dword,AddRef)() = 0;
   INETMETHOD_(dword,Release)() = 0;
                              //adding data
   INETMETHOD_(void,AddByte)(byte, int msg_type) = 0;
   INETMETHOD_(void,AddWord)(word, int msg_type) = 0;
   INETMETHOD_(void,AddDword)(dword, int msg_type) = 0;
   INETMETHOD_(void,AddFloat)(float, int msg_type) = 0;
   INETMETHOD_(void,AddVector)(const struct S_vector&, int msg_type) = 0;
   INETMETHOD_(void,AddID)(word, int msg_type) = 0;
   INETMETHOD_(void,AddBits)(dword, dword num_bits, int msg_type) = 0;
//----------------------------
// Add NULL-terminated string into message, including the terminating '/0' character.
   INETMETHOD_(void,AddString)(const char*, int msg_type) = 0;
                              //chunk management
   INETMETHOD_(void,Ascend)(word) = 0;
   INETMETHOD_(void,Descend)() = 0;
                              //rest
   INETMETHOD_(void,Clear)() = 0;
                              //get size in bits
   INETMETHOD_(dword,GetSize)(int msg_type) const = 0;
};

//----------------------------
                              //incomming message
class C_net_in_msg2{
public:
   INETMETHOD_(dword,AddRef)() = 0;
   INETMETHOD_(dword,Release)() = 0;

   INETMETHOD_(byte,GetByte)() = 0;
   INETMETHOD_(word,GetWord)() = 0;
   INETMETHOD_(dword,GetDword)() = 0;
   INETMETHOD_(float,GetFloat)() = 0;
   INETMETHOD_(struct S_vector,GetVector)() = 0;
   INETMETHOD_(dword,GetID)() = 0;
   INETMETHOD_(dword,GetBits)(dword num_bits) = 0;
//----------------------------
// Read NULL-terminated string from message. No more than 'max_len' characters are put
// into the buffer. The string is always read complete, regardless of buffer size.
   INETMETHOD_(void,GetString)(char *buf, dword max_len) = 0;
   INETMETHOD_(void,Ascend)() = 0;
   INETMETHOD_(void,Descend)() = 0;
   INETMETHOD_(void,SkipChunk)() = 0;
   INETMETHOD_(void,Skip)(dword) = 0;
   //INETMETHOD_(bool,ChunkEnd)() const = 0;

//----------------------------
// Get number of bits left in currently ascended chunk.
   INETMETHOD_(dword,GetChunkSize)() const = 0;

   INETMETHOD_(dword,GetPos)() const = 0;
   INETMETHOD_(void*,GetBuf)() const = 0;

//----------------------------
// Get latency, in which this message arrived.
// Currently not implemented, returning 0.
   INETMETHOD_(dword,GetLatency)() const = 0;

//----------------------------
// Get PID of sender. If returned value is 0, the message is a system one,
// and contains commands of INET_SYSTEM_MESSAGE enum.
   INETMETHOD_(dword,GetSenderPID)() const = 0;

//----------------------------
// Get size of the message, in bits.
   INETMETHOD_(dword,GetSize)() const = 0;
};



#endif

//----------------------------
                              //create network interface
PI_net INETAPI InetCreate(PINET_INIT init_data, bool use_debug_version);

//----------------------------//C-S interface

PI_net_client INETAPI InetClientCreate(PINET_INIT init_data, bool use_debug_version);

PI_net_server INETAPI InetServerCreate(PINET_INIT init_data, bool use_debug_version);

//----------------------------
                              //system messages - they have PID = 0
enum INET_SYSTEM_MESSAGE{
                              //new player created
                              //data:
                              // - dword pid
   INET_SYSMSG_PLAYER_CREATED = 1,

                              //player destroyed
                              //data:
                              // - dword pid
                              // - null-terminated string plr_name
   INET_SYSMSG_PLAYER_DESTROYED = 2,

                              //host migrated
                              //data:
                              // - dword new_host_pid
   INET_SYSMSG_HOST_MIGRATED = 3,

                              //session terminated
                              //data:
   INET_SYSMSG_SESSION_OVER = 4,

   INET_SYSTEM_MESSAGE_FORCE_WORD = 0x7fff
};

//----------------------------
enum E_INET_MESSAGE_TYPE{
   INET_MSG_NG = 0,           //non-guaranteed
   INET_MSG_G = 1,            //guaranteed
   INET_MSG_NGP = 2,          //non-guaranteed with priority (cannot be dropped)
   INET_MSG_LAST
};

#ifndef INET_FULL

                              //outgoing message
class C_net_out_msg{
public:
   INETMETHOD_(dword,AddRef)() = 0;
   INETMETHOD_(dword,Release)() = 0;
                              //adding data
   INETMETHOD_(void,AddByte)(byte, int msg_type) = 0;
   INETMETHOD_(void,AddWord)(word, int msg_type) = 0;
   INETMETHOD_(void,AddDword)(dword, int msg_type) = 0;
   INETMETHOD_(void,AddFloat)(float, int msg_type) = 0;
   INETMETHOD_(void,AddVector)(const struct S_vector&, int msg_type) = 0;
   INETMETHOD_(void,AddVector2)(const struct S_vector2&, int msg_type) = 0;
   INETMETHOD_(void,AddID)(word, int msg_type) = 0;
   INETMETHOD_(void,AddBits)(dword, dword num_bits, int msg_type) = 0;
//----------------------------
// Add NULL-terminated string into message, including the terminating '/0' character.
   INETMETHOD_(void,AddString)(const char*, int msg_type) = 0;
                              //chunk management
   INETMETHOD_(void,Ascend)(word) = 0;
   INETMETHOD_(void,Descend)() = 0;
                              //rest
   INETMETHOD_(void,Clear)() = 0;
                              //get size in bits
   INETMETHOD_(dword,GetSize)(int msg_type) const = 0;
};

//----------------------------
                              //incomming message
class C_net_in_msg{
public:
   INETMETHOD_(dword,AddRef)() = 0;
   INETMETHOD_(dword,Release)() = 0;

   INETMETHOD_(byte,GetByte)() = 0;
   INETMETHOD_(word,GetWord)() = 0;
   INETMETHOD_(dword,GetDword)() = 0;
   INETMETHOD_(float,GetFloat)() = 0;
   INETMETHOD_(struct S_vector,GetVector)() = 0;
   INETMETHOD_(struct S_vector2,GetVector2)() = 0;
   INETMETHOD_(dword,GetID)() = 0;
   INETMETHOD_(dword,GetBits)(dword num_bits) = 0;
//----------------------------
// Read NULL-terminated string from message. No more than 'max_len' characters are put
// into the buffer. The string is always read complete, regardless of buffer size.
   INETMETHOD_(void,GetString)(char *buf, dword max_len) = 0;
   INETMETHOD_(void,Ascend)() = 0;
   INETMETHOD_(void,Descend)() = 0;
   INETMETHOD_(void,SkipChunk)() = 0;
   INETMETHOD_(void,Skip)(dword) = 0;
   //INETMETHOD_(bool,ChunkEnd)() const = 0;

//----------------------------
// Get number of bits left in currently ascended chunk.
   INETMETHOD_(dword,GetChunkSize)() const = 0;

   INETMETHOD_(dword,GetPos)() const = 0;
   INETMETHOD_(void*,GetBuf)() const = 0;

//----------------------------
// Get latency, in which this message arrived.
// Currently not implemented, returning 0.
   INETMETHOD_(dword,GetLatency)() const = 0;

//----------------------------
// Get PID of sender. If returned value is 0, the message is a system one,
// and contains commands of INET_SYSTEM_MESSAGE enum.
   INETMETHOD_(dword,GetSenderPID)() const = 0;

//----------------------------
// Get size of the message, in bits.
   INETMETHOD_(dword,GetSize)() const = 0;
};

#endif

//----------------------------

#endif //__INET2_H
