

using namespace std;

#define USE_CRC_CHECK             //enable CRC checking on messages (adds 4 bytes to each message)

//#ifdef _DEBUG
#if 1

# define NET_LOG(n) if(log_func) (*log_func)(n)
# define NET_LOG1(n) if(init_data.log_func) (*init_data.log_func)(n)
//# define NET_LOG(n)
//# define FATAL(msg, title) { AssertMsg(0, msg); }
inline void Fatal(const char *msg, const char *title){
   MessageBox(NULL, msg, title, MB_OK);
   assert(0);
}

#else

# define NET_LOG(n)
# define FATAL(msg, title)

#endif

//----------------------------

enum E_BUFFER_TYPE{
   E_BUFFERTYPE_UNKNOWN,
   E_BUFFERTYPE_NEW_ALLOCATED,//buffer allocated by new byte[]
   E_BUFFERTYPE_DPLAY,        //buffer which must be returned to DPlay
};

//----------------------------

class C_net_out_msg_base{
public:
   INETMETHOD_(dword,AddRef)() = 0;
   INETMETHOD_(dword,Release)() = 0;

   INETMETHOD_(void,AddByte)(byte, int msg_type) = 0;
   INETMETHOD_(void,AddWord)(word, int msg_type) = 0;
   INETMETHOD_(void,AddDword)(dword, int msg_type) = 0;
   INETMETHOD_(void,AddFloat)(float, int msg_type) = 0;
   INETMETHOD_(void,AddVector)(const struct S_vector&, int msg_type) = 0;
   INETMETHOD_(void,AddVector2)(const struct S_vector2&, int msg_type) = 0;
   INETMETHOD_(void,AddID)(word, int msg_type) = 0;
   INETMETHOD_(void,AddBits)(dword, dword num_bits, int msg_type) = 0;
   INETMETHOD_(void,AddString)(const char*, int msg_type) = 0;
   INETMETHOD_(void,Ascend)(word) = 0;
   INETMETHOD_(void,Descend)() = 0;
   INETMETHOD_(void,Clear)() = 0;
   INETMETHOD_(dword,GetSize)(int msg_type) const = 0;
};

//----------------------------

class C_net_in_msg_base{
public:
   INETMETHOD_(dword,AddRef)() = 0;
   INETMETHOD_(dword,Release)() = 0;

   INETMETHOD_(byte,GetByte)() = 0;
   INETMETHOD_(word,GetWord)() = 0;
   INETMETHOD_(dword,GetDword)() = 0;
   INETMETHOD_(float,GetFloat)() = 0;
   INETMETHOD_(struct S_vector,GetVector)() = 0;
   INETMETHOD_(struct S_vector2,GetVector2)() = 0;
   INETMETHOD_(dword,GetID)() = 0;
   INETMETHOD_(dword,GetBits)(dword num_bits) = 0;
   INETMETHOD_(void,GetString)(char *buf, dword max_len) = 0;
   INETMETHOD_(void,Ascend)() = 0;
   INETMETHOD_(void,Descend)() = 0;
   INETMETHOD_(void,SkipChunk)() = 0;
   INETMETHOD_(void,Skip)(dword) = 0;
   //INETMETHOD_(bool,ChunkEnd)() const = 0;
   INETMETHOD_(dword,GetChunkSize)() const = 0;
   INETMETHOD_(dword,GetPos)() const = 0;
   INETMETHOD_(void*,GetBuf)() const = 0;

   INETMETHOD_(dword,GetLatency)() const = 0;
   INETMETHOD_(dword,GetSenderPID)() const = 0;
   INETMETHOD_(dword,GetSize)() const = 0;
};

//----------------------------
                              //network interface class
class I_net_base{
public:
   INETMETHOD_(dword,AddRef)() = 0;
   INETMETHOD_(dword,Release)() = 0;
                              //interfaces:
   INETMETHOD_(bool,IsHost)() const = 0;
   INETMETHOD_(E_NET_STATUS,GetStatus)() const = 0;
                              //player
   INETMETHOD_(bool,GetPlayerName)(dword plr_id, C_str&) const = 0;
   INETMETHOD_(dword,GetPID)() const = 0;
   INETMETHOD_(dword,GetHostPID)() const = 0;
                              //messages
   INETMETHOD_(bool,Send)(PC_net_out_msg, dword id_to = 0, dword flags = 0) = 0;
   INETMETHOD_(void,ProcessMessages)(INET_MESSAGECALLBACK *plr_proc, dword context = 0, dword flags = 0) = 0;

   INETMETHOD_(PC_net_out_msg,CreateOutMsg)() = 0;
                              //sessions
   INETMETHOD_(bool,EnumSessions)(PINET_session_address*, dword *num_sessions) = 0;
   INETMETHOD_(bool,GetPlayers)(dword *pids, dword *num_players) const = 0;
   INETMETHOD_(bool,HostSession)(dword flags) = 0;
   INETMETHOD_(bool,JoinSession)(CPINET_session_address) = 0;
   INETMETHOD_(bool,InitVoice)(void *focus_hwnd, struct IDirectSound8 *dsound = NULL) = 0;
   INETMETHOD_(void,CloseVoice)() = 0;
   INETMETHOD_(bool,TestVoice)(void *hwnd, bool force_test) = 0;
   INETMETHOD_(bool,Close)() = 0;
   INETMETHOD_(bool,SetOpen)(bool) = 0;
                              //debugging
   //INETMETHOD_(void,GetStats)(dword *in, dword *out_g, dword *out_ng) = 0;
   INETMETHOD_(void,GetStats)(I3D_stats_net &) = 0;
   INETMETHOD_(void,Log)(const char*) = 0;
   INETMETHOD_(IDirectPlay8Peer*,GetDPInterface)() const = 0;
};

//----------------------------

#pragma pack (push,1)
struct S_msg_header{
   byte bits_left:3;
   byte guaranteed:1;
   //byte internal_msg:1;       //internal system message
#ifdef USE_CRC_CHECK
   dword crc_check;
#endif

   dword msg_id;               //message ID (for debugging and message order)
};
#pragma pack(pop)

//----------------------------
                              //a memory buffer which holds its contents only until
                              // it's not released

struct S_memory_buffer: public C_unknown{
   void *data;
   dword size;

   friend class C_net_out_msg;

   S_memory_buffer(): data(NULL), size(0)
   {}
   S_memory_buffer(const S_memory_buffer&);
   S_memory_buffer operator =(const S_memory_buffer&);
   ~S_memory_buffer(){
      free(data);
   }
public:
   S_memory_buffer(void *d1, dword s1):
      data(malloc(s1)),
      size(s1)
   {
      memcpy(data, d1, size);
   }

   inline const void *GetData() const{ return data; }
   inline dword GetSize() const{ return size; }
};

typedef S_memory_buffer *PS_memory_buffer;
typedef const S_memory_buffer *CPS_memory_buffer;

//----------------------------
                              //network outgoing message
class C_net_out_msg: public C_net_out_msg_base{
   dword ref;

   INET_INIT::t_log_func *log_func;
   INET_INIT::t_msg_to_string *msg_to_string;
                              //single message queue
                              //n separate are kept, for each E_INET_MESSAGE_TYPE type
   struct S_queue{
      byte *buf;
      dword buf_size, buf_alloc_size;

      struct S_level{
         dword pos, msg_id;
         S_level(){}
         S_level(dword pos1, dword msg_id1):
            pos(pos1),
            msg_id(msg_id1)
         {}
         inline bool operator <(const S_level &l) const{ return (pos<l.pos); }
         inline bool operator!=(const S_level &l) const{ return (pos!=l.pos); }
         inline operator dword() const{ return pos; }
      };
      stack<S_level, vector<S_level> > level;
      byte bits_left;
                              //chunk history for concanetating
      struct S_make_chunk{
         dword pos;
         dword parent_pos;    //-1 = no parent
         dword msg_id;
         dword chunk_size;
      };
      S_make_chunk last_closed_chunk;
      bool last_closed_chunk_valid;

      S_queue():
         buf(NULL), buf_size(0), buf_alloc_size(0),
         bits_left(0),
         last_closed_chunk_valid(false)
      {
         Clear();
      }
      ~S_queue(){
         free(buf);
      }
      void Clear();
      void AddBits1(byte b, dword num_bits);
      inline void AddByte(byte b){
         if(bits_left){
            buf[buf_size-1] |= (b << (8-bits_left));
            b >>= bits_left;
         }
         if(buf_size == buf_alloc_size){
            buf = (byte*)realloc(buf, (buf_alloc_size = Max(16, (int)buf_alloc_size * 2)) + 4);
         }
         buf[buf_size++] = b;
      }
      inline void AddWord(word w){
         AddByte(w);
         AddByte(w>>8);
      }
      inline void AddDword(dword d){
         AddWord(d);
         AddWord(d>>16);
      }
      inline void AddID(word id){
         AddWord(id);
      }
      void Ascend(word msg_id);
      void Descend(INET_INIT::t_log_func*);
   } msg[INET_MSG_LAST];
public:
   C_net_out_msg(INET_INIT::t_log_func *lf, INET_INIT::t_msg_to_string *ms):
      log_func(lf),
      msg_to_string(ms),
      ref(1)
   {}
public:
   dword INETAPI AddRef(){ return ++ref; }
   dword INETAPI Release(){ if(--ref) return ref; delete this; return 0; }

//----------------------------

   virtual void INETAPI AddByte(byte b, int msg_type);
   virtual void INETAPI AddWord(word w, int msg_type);
   virtual void INETAPI AddDword(dword d, int msg_type);
   virtual void INETAPI AddFloat(float f, int msg_type);
   virtual void INETAPI AddVector(const struct S_vector &v, int msg_type);
   virtual void INETAPI AddVector2(const struct S_vector2&, int msg_type);
   virtual void INETAPI AddID(word id, int msg_type);
   virtual void INETAPI AddBits(dword dw, dword num_bits, int msg_type);
   virtual void INETAPI AddString(const char *cp, int msg_type);

//----------------------------

   virtual void INETAPI Ascend(word msg_id){

      assert(msg_id != 0);
      for(int i=0; i<INET_MSG_LAST; i++)
         msg[i].Ascend(msg_id);
   }

//----------------------------

   virtual void INETAPI Descend(){

      for(int i=0; i<INET_MSG_LAST; i++)
         msg[i].Descend(log_func);
   }

//----------------------------

   virtual void INETAPI Clear(){
      for(int i=0; i<INET_MSG_LAST; i++)
         msg[i].Clear();
   }

//----------------------------

   virtual dword INETAPI GetSize(int msg_type) const{

      assert(msg_type<INET_MSG_LAST);
      return (msg[msg_type].buf_size-sizeof(S_msg_header)) * 8 - msg[msg_type].bits_left;
   }

//----------------------------

   bool Lock(byte **data1, dword *size1, int msg_type, dword pid_sender);

//----------------------------
// Convert the contents of message into a memory buffer.
   PS_memory_buffer GetBuffer(int msg_type, dword pid_sender);
};

//----------------------------
                              //network incomming message
class C_net_in_msg: public C_net_in_msg_base{
   dword ref;

   byte *data;
   dword pos, size;           //in bits
   stack<dword, vector<dword> > level;
   dword sender_pid;
   const char *plr_name;

   C_smart_ptr<IDirectPlay8Peer> lpDP8;
   DPNHANDLE buf_handle;
   E_BUFFER_TYPE buff_type;
                              //debugging
   word last_descend_chunk;

   bool IsEnd() const{
      return (pos>=size);
   }
   INET_INIT::t_log_func *log_func;
   INET_INIT::t_msg_to_string *msg_to_string;

   inline void VerifyPosition() const{
#ifdef _DEBUG
      if(pos>level.top())
         Fatal(C_fstr("C_net_in_msg::GetID: got past end of chunk - %i bits.\nlast_descend_chunk = 0x%x", pos-level.top(), last_descend_chunk), plr_name);
#endif
   }
public:
   C_net_in_msg(PDIRECTPLAY8PEER, DPNHANDLE, E_BUFFER_TYPE, INET_INIT::t_log_func*, INET_INIT::t_msg_to_string*, const char *plr_name1,
      const void *vp, dword s1, dword pid);
   ~C_net_in_msg();

   dword INETAPI AddRef();
   dword INETAPI Release();

   byte GetBits1(dword num_bits);

   inline byte GetByte1(){ return GetBits1(8); }
   inline word GetWord1(){ byte lo = GetByte1(); return lo | (GetByte1()<<8); }
   inline dword GetDword1(){ word lo = GetWord1(); return lo | (GetWord1()<<16); }

   virtual byte INETAPI GetByte(){
      byte b = GetBits1(8);
      NET_LOG(C_fstr("%.*sGetByte: 0x%.2x\n", level.size(), "        ", b));
      return b;
   }
   virtual word INETAPI GetWord(){
      word w = GetWord1();
      NET_LOG(C_fstr("%.*sGetWord: 0x%.4x\n", level.size(), "        ", w));
      return w;
   }
   virtual dword INETAPI GetDword(){
      dword dw = GetDword1();
      NET_LOG(C_fstr("%.*sGetDword: 0x%.8x\n", level.size(), "        ", dw));
      return dw;
   }
   virtual float INETAPI GetFloat(){
      dword dw = GetDword1();
      float f = *(float*)&dw;
      NET_LOG(C_fstr("%.*sGetFloat: %.2f (0x%x)\n", level.size(), "        ", f, *(dword*)&f));
      return f;
   }
   virtual S_vector INETAPI GetVector(){
      S_vector v;
      *(dword*)&v.x = GetDword1();
      *(dword*)&v.y = GetDword1();                   
      *(dword*)&v.z = GetDword1();
      NET_LOG(C_fstr("%.*sGetVector: [%.2f. %.2f, %.2f] (0x%x, 0x%x, 0x%x)\n", level.size(), "        ", v.x, v.y, v.z, *(dword*)&v.x, *(dword*)&v.y, *(dword*)&v.z));
      return v;
   }
   virtual S_vector2 INETAPI GetVector2(){
      S_vector2 v;
      *(dword*)&v.x = GetDword1();
      *(dword*)&v.y = GetDword1();                   
      NET_LOG(C_fstr("%.*sGetVector2: [%.2f. %.2f] (0x%x, 0x%x)\n", level.size(), "        ", v.x, v.y, *(dword*)&v.x, *(dword*)&v.y));
      return v;
   }
   virtual dword INETAPI GetID(){

      VerifyPosition();
      if(pos==level.top()) return 0;
      dword nm = GetWord1();
                              //shouldn't have explicit NM_NULL in message
      VerifyPosition();
      NET_LOG(C_fstr("%.*sGetID: 0x%.4x\n", level.size(), "        ",
         nm, !msg_to_string ? "" : (*msg_to_string)(nm)));
      assert(nm != 0);
      return nm;
   }
   virtual dword INETAPI GetBits(dword num_bits){
#ifdef DEBUG_ALIGN_BITS_8
      if(num_bits<=8) num_bits = 8;
      else
      if(num_bits<=16) num_bits = 16;
      else num_bits = 32;
#endif

      dword ret = 0;
      dword pos = 0;
      while(num_bits>=8){
         ret |= GetByte1() << pos;
         pos += 8;
         num_bits -= 8;
      }
      if(num_bits)
         ret |= GetBits1(num_bits) << pos;
      NET_LOG(C_fstr("%.*sGetBits:%i: 0x%x\n", level.size(), "        ", pos+num_bits, ret));
      return ret;
   }

   virtual void INETAPI GetString(char *buf, dword max_len){

      char *cp = buf;
      int len = max_len;
      char c;
      do{
         c = GetBits1(8);
         if(--len > 0)
            *cp++ = c;
      }while(c);
      if(max_len){
         if(len < 0)
            *cp = 0;
      }
      NET_LOG(C_fstr("%.*sGetString: %s\n", level.size(), "        ", buf));
   }
   virtual void INETAPI Ascend();
   virtual void INETAPI Descend();
   virtual void INETAPI SkipChunk(){
      word w = GetWord1();
      pos += w;
      NET_LOG(C_fstr("%.*sSkipChunk: %i bits\n", level.size(), "        ", w));
      VerifyPosition();
   }
   virtual void INETAPI Skip(dword num){
      pos += num;
      VerifyPosition();
   }
   virtual dword INETAPI GetPos() const{
      return pos;
   }
   virtual void *INETAPI GetBuf() const{
      return &data[pos/8];
   }

   virtual dword INETAPI GetChunkSize() const{
      return level.top() - pos;
   }

   virtual dword INETAPI GetLatency() const{
                              //not working properly
      return 0;
   }

   virtual dword INETAPI GetSenderPID() const{
      return sender_pid;
   }

   virtual dword INETAPI GetSize() const{ return size; }

   inline const S_msg_header &GetHeader() const{ return *(S_msg_header*)data; }
};

//----------------------------
