#include "all.h"
#include "inet_i.h"
#include <insanity\assert.h>


//#define LOG_DUMP              //dump message content to log file (if logging enabled)

//----------------------------

static const byte bit_mask[] = {0x00, 0x01, 0x03, 0x07, 0x0f, 0x1f, 0x3f, 0x7f, 0xff};

static dword message_id = 0;

//----------------------------

#ifdef USE_CRC_CHECK

static class C_crc32{
public:
   dword crctab[256];
   C_crc32()
   {
      const dword poly = 0xEDB88320L;
      for(int i=0; i<256; i++){
         dword crc = i;
         for(int j=8; j>0; j--){
         if(crc&1)
            crc = (crc >> 1) ^ poly;
         else
            crc >>= 1;
         }
         crctab[i] = crc;
      }
   }
} crctab;

dword GetCRC32(const byte *data, dword len){

   dword ret = 0xffffffff;
   for(dword i=0; i<len; i++){
      byte b = *data++;
      ret = ((ret>>8) & 0x00ffffff) ^ crctab.crctab[(ret^b)&0xff];
   }
   return ret;
}
#endif

//----------------------------
//----------------------------

#ifdef USE_CRC_CHECK
#include <iexcpt.h>
#endif

//----------------------------

C_net_in_msg::C_net_in_msg(PDIRECTPLAY8PEER lpDP8a, DPNHANDLE hnd, E_BUFFER_TYPE bt1,
   INET_INIT::t_log_func *lf, INET_INIT::t_msg_to_string *ms,
   const char *plr_name1, const void *vp, dword s1, dword pid):

   ref(1),
   log_func(lf),
   msg_to_string(ms),
   plr_name(plr_name1),
   data((byte*)vp),
   size(s1*8),
   sender_pid(pid),
   last_descend_chunk(0),
   lpDP8(lpDP8a),
   buf_handle(hnd),
   buff_type(bt1),
   pos(0)
{
   assert(s1 >= sizeof(S_msg_header));
   const S_msg_header &hdr = *(S_msg_header*)data;

#ifdef USE_CRC_CHECK
   if(lpDP8a){
      dword crc32 = GetCRC32(data+sizeof(S_msg_header), s1-sizeof(S_msg_header));
      bool crc_ok = (crc32==hdr.crc_check);
      if(!crc_ok){
         UserException("INet fatal error", C_fstr(
            "\r\n"
            "*** Fatal error: CRC mismatch on network message from player '%s'.\r\n"
            "Probable cause: your network adapter, or adapter of mentioned player,\r\nis altering messages, so that they arrive corrupted.\r\n"
            "Solution: try upgrading your network card drivers to reliable version.\r\n"
            "The application will now terminate.\r\n"
            , plr_name));
         _exit(0);
      }
   }
#endif
   size -= hdr.bits_left;

   pos += sizeof(S_msg_header)*8;

#ifdef _DEBUG
# ifdef LOG_DUMP
   if(os_log){
      (*os_log)<<"Dump: " <<hex;
      for(int i=0; i<s1; i++) (*os_log)<<(dword)data[i] <<(i<s1-1 ? "," : "\n");
   }
# endif
#endif
                           //build root level
   level.push(size);
}

//----------------------------

C_net_in_msg::~C_net_in_msg(){

   NET_LOG("----------------------\n");

   switch(buff_type){
   case E_BUFFERTYPE_DPLAY:
      lpDP8->ReturnBuffer(buf_handle, 0);
      break;

   case E_BUFFERTYPE_NEW_ALLOCATED:
      delete[] (byte*)data;
      break;
   }
}

//----------------------------

dword C_net_in_msg::AddRef(){ return ++ref; }
dword C_net_in_msg::Release(){ if(--ref) return ref; delete this; return 0; }

//----------------------------

byte C_net_in_msg::GetBits1(dword num_bits){

   dword ret = 0;
   dword bits_left = 8 - (pos&7);
   if(num_bits<=bits_left) ret = data[pos/8];
   else ret = *(word*)&data[pos/8];
   ret >>= (pos&7);
   pos += num_bits;
   ret &= bit_mask[num_bits];
   return ret;
}

//----------------------------

void C_net_in_msg::Ascend(){

#ifdef _DEBUG
   pos -= 16;
   last_descend_chunk = GetWord1();
#endif
                           //save end of this chunk
   dword ck_size = GetWord1();
   level.push(pos + ck_size);
   NET_LOG(C_fstr("%.*sAscend: size = %i bits\n", level.size(), "        ", ck_size));
}

//----------------------------

void C_net_in_msg::Descend(){
   
   assert(level.size()>1);
   VerifyPosition();
                           //properly-written programs should finish exactly
   if(pos!=level.top()){
      NET_LOG(C_fstr("%.*sDescend: %i bits undread from chunk!!!\n", level.size(), "        ", GetChunkSize()));
   }
                           //set position to end of this chunk
   pos = level.top();
   level.pop();
}

//----------------------------
//----------------------------

static const char *msg_type_desc[INET_MSG_LAST] = {
   "ng", "g", "ngp"
};

//----------------------------

void C_net_out_msg::AddByte(byte b, int msg_type){

   assert(msg_type<INET_MSG_LAST);
   msg[msg_type].AddByte(b);
   NET_LOG(C_fstr("%.*sAddByte%s: 0x%.2x\n", msg[msg_type].level.size(), "        ", msg_type_desc[msg_type], b));
}

//----------------------------

void C_net_out_msg::AddWord(word w, int msg_type){

   assert(msg_type<INET_MSG_LAST);
   msg[msg_type].AddWord(w);
   NET_LOG(C_fstr("%.*sAddWord%s: 0x%.4x\n", msg[msg_type].level.size(), "        ", msg_type_desc[msg_type], w));
}

//----------------------------

void C_net_out_msg::AddDword(dword d, int msg_type){

   assert(msg_type<INET_MSG_LAST);
   msg[msg_type].AddWord(d);
   msg[msg_type].AddWord(d>>16);
   NET_LOG(C_fstr("%.*sAddDword%s: 0x%.8x\n", msg[msg_type].level.size(), "        ", msg_type_desc[msg_type], d));
}

//----------------------------

void C_net_out_msg::AddFloat(float f, int msg_type){

   assert(msg_type<INET_MSG_LAST);
   msg[msg_type].AddDword(*(dword*)&f);
   NET_LOG(C_fstr("%.*sAddFloat%s: %.2f (0x%x)\n", msg[msg_type].level.size(), "        ", msg_type_desc[msg_type],
      f, *(dword*)&f));
}

//----------------------------

void C_net_out_msg::AddVector(const struct S_vector &v, int msg_type){

   assert(msg_type<INET_MSG_LAST);
   msg[msg_type].AddDword(*(dword*)&v.x);
   msg[msg_type].AddDword(*(dword*)&v.y);
   msg[msg_type].AddDword(*(dword*)&v.z);
   NET_LOG(C_fstr("%.*sAddVector%s: [%.2f. %.2f, %.2f] (0x%x, 0x%x, 0x%x)\n", msg[msg_type].level.size(),
      "        ", msg_type_desc[msg_type], v.x, v.y, v.z, *(dword*)&v.x, *(dword*)&v.y, *(dword*)&v.z));
}

//----------------------------

void C_net_out_msg::AddVector2(const struct S_vector2 &v, int msg_type){

   assert(msg_type<INET_MSG_LAST);
   msg[msg_type].AddDword(*(dword*)&v.x);
   msg[msg_type].AddDword(*(dword*)&v.y);
   NET_LOG(C_fstr("%.*sAddVector2%s: [%.2f. %.2f] (0x%x, 0x%x)\n", msg[msg_type].level.size(),
      "        ", msg_type_desc[msg_type], v.x, v.y, *(dword*)&v.x, *(dword*)&v.y));
}

//----------------------------

void C_net_out_msg::AddID(word id, int msg_type){

   assert(msg_type<INET_MSG_LAST);
   msg[msg_type].AddWord(id);
   NET_LOG(C_fstr("%.*sAddID%s: 0x%.4x (%s)\n", msg[msg_type].level.size(), "        ",
      msg_type_desc[msg_type], id, !msg_to_string ? "" : (*msg_to_string)(id)));
}

//----------------------------

void C_net_out_msg::AddBits(dword dw, dword num_bits, int msg_type){

   assert(msg_type<INET_MSG_LAST);
   assert(num_bits && num_bits<=32);
   if(!num_bits) return;
#ifdef DEBUG_ALIGN_BITS_8
   if(num_bits<=8) num_bits = 8;
   else
   if(num_bits<=16) num_bits = 16;
   else num_bits = 32;
#endif
   assert(dw < dword(1<<num_bits));
   NET_LOG(C_fstr("%.*sAddBits%s:%i: 0x%x\n", msg[msg_type].level.size(), "        ",
      msg_type_desc[msg_type], num_bits, dw));
   while(num_bits>=8){
      msg[msg_type].AddByte(dw);
      dw >>= 8;
      num_bits -= 8;
   }
   if(num_bits)
      msg[msg_type].AddBits1(dw, num_bits);
}

//----------------------------

void C_net_out_msg::AddString(const char *cp, int msg_type){

   assert(msg_type<INET_MSG_LAST);
   NET_LOG(C_fstr("%.*sAddString%s: %s\n", msg[msg_type].level.size(), "        ", msg_type_desc[msg_type], cp));
   do{
      msg[msg_type].AddByte(*cp);
   }while(*cp++);
}

//----------------------------



//----------------------------

void C_net_out_msg::S_queue::Clear(){

   last_closed_chunk_valid = false;
                        //save work if nothing changed from last call
   if(buf_size==sizeof(S_msg_header) && !bits_left)
      return;

   //buf = NULL;
   //buf_size = 0;
   //buf_alloc_size = 0;
   while(!level.empty())
      level.pop();
   bits_left = 0;
   free(buf);
                        //reserve bits for header
   buf_size = buf_alloc_size = sizeof(S_msg_header);
   buf = (byte*)malloc(buf_alloc_size + 4);
}

//----------------------------

void C_net_out_msg::S_queue::AddBits1(byte b, dword num_bits){

   assert(num_bits>0 && num_bits<=8);
   b &= bit_mask[num_bits];
   if(!bits_left){
      bits_left = 8 - num_bits;
      if(buf_size == buf_alloc_size){
         buf = (byte*)realloc(buf, (buf_alloc_size = Max(16, (int)buf_alloc_size * 2)) + 4);
      }
      buf[buf_size++] = b;
      return;
   }
   int pos = 8-bits_left;
   buf[buf_size-1] |= (b << pos);
   if(bits_left<num_bits){
      if(buf_size == buf_alloc_size){
         buf = (byte*)realloc(buf, (buf_alloc_size = Max(16, (int)buf_alloc_size * 2)) + 4);
      }
      buf[buf_size++] = (b >> bits_left);

      bits_left += 8;
   }
   bits_left -= num_bits;
}

//----------------------------

void C_net_out_msg::S_queue::Ascend(word msg_id){
                        //try to concanetate
   dword parent_pos = level.size() ? level.top() : -1;
   if(last_closed_chunk_valid &&
      last_closed_chunk.msg_id==msg_id &&
      last_closed_chunk.parent_pos==parent_pos &&
      last_closed_chunk.pos + last_closed_chunk.chunk_size == (buf_size*8-bits_left))
   {

                        //ok, map to previous chunk
      level.push(S_level(last_closed_chunk.pos, msg_id));
      last_closed_chunk_valid = false;
   }else{
                        //save current position
      level.push(S_level(buf_size * 8 - bits_left, msg_id));
                        //store ID plus save space for chunk size
      AddID(msg_id); AddWord(0);
   }
}

//----------------------------

void C_net_out_msg::S_queue::Descend(INET_INIT::t_log_func *log_func){

   assert(level.size());
   dword pos = level.top();
   dword msg_id = level.top().msg_id;
   level.pop();
   dword ck_size = buf_size * 8 - bits_left - pos - 8*4;
   if(ck_size){
      assert(ck_size<0x10000);
                              //write chunk size to chunk header
      dword bit_pos = pos&7;
      (*(dword*)&buf[pos/8+2]) &= ~(0xffff << bit_pos);
      (*(dword*)&buf[pos/8+2]) |= (ck_size << bit_pos);
                              //save successive-built chunk
      S_make_chunk &mc = last_closed_chunk;
      mc.pos = pos;
      mc.parent_pos = level.size() ? level.top() : -1;
      mc.msg_id = msg_id;
      mc.chunk_size = ck_size + 8*4;
      last_closed_chunk_valid = true;

      NET_LOG(C_fstr("%.*sChunk closed: id = 0x%.4x, size = %i bits\n", level.size(), "        ", msg_id, ck_size));
   }else{
                              //zero-sized chunk, remove ID
      buf_size -= 4;
                              //clear bits in last partially-filled byte
      if(bits_left){
         buf[buf_size-1] &= bit_mask[8-bits_left];
      }
   }
}

//----------------------------

PS_memory_buffer C_net_out_msg::GetBuffer(int msg_type, dword pid_sender){

   assert(msg_type<INET_MSG_LAST);

   S_queue &queue = msg[msg_type];
   dword buf_size = queue.buf_size;
   if(buf_size<=sizeof(S_msg_header)){
      return NULL;
   }

   PS_memory_buffer mem_buf = new S_memory_buffer;

                              //move ownership of the buffer to the new memory buffer
   mem_buf->data = queue.buf;
   mem_buf->size = buf_size;

                              //clear our pointers
   queue.buf = NULL;
   queue.buf_size = 0;
   queue.buf_alloc_size = 0;

                              //fill-in header
   S_msg_header &hdr = *(S_msg_header*)mem_buf->data;
   *(byte*)&hdr = 0;          //clear 1st byte
   hdr.bits_left = queue.bits_left;
   hdr.guaranteed = (msg_type==INET_MSG_G);

   hdr.msg_id = message_id++;

#ifdef USE_CRC_CHECK
   hdr.crc_check = GetCRC32(((byte*)mem_buf->data)+sizeof(S_msg_header), buf_size-sizeof(S_msg_header));
#endif

#ifdef _DEBUG
# ifdef LOG_DUMP
   if(os_log){
      (*os_log)<<"Dump: " <<hex;
      for(int i=0; i<buf_size; i++) (*os_log)<<(dword)msg[g].data[i] <<(i<size-1 ? "," : "\n");
   }
# endif
#endif

   return mem_buf;
}

//----------------------------
//----------------------------
