

//----------------------------
                              //C_timer
                              // - using Performance Counter if available, otherwise using GetTickCount
class C_timer{
   //bool use_qpc;              //true if Performance Counter is used
   //dword qpc_freq;
   //LARGE_INTEGER qpc_start_t0;

   dword gtc_start_time;
public:
   C_timer()
   {
      /*
                              //init timer
      LARGE_INTEGER li;
      use_qpc = QueryPerformanceFrequency(&li);
      if(use_qpc){
         qpc_freq = li.LowPart;
         QueryPerformanceCounter(&qpc_start_t0);
         //qpc_start_t0.LowPart -= Random(5000);
      }else{
         gtc_start_time = GetTickCount();
      }
      */

      gtc_start_time = GetTickCount();
   }
                              //Return current time in msec since the class was initialized
                              // (this means since this DLL was loaded)
   dword GetTime(){
      /*
      if(use_qpc){
         LARGE_INTEGER li;
         QueryPerformanceCounter(&li);
         return MulDiv(li.LowPart - qpc_start_t0.LowPart, 1000, qpc_freq);
      }else{
         return GetTickCount() - gtc_start_time;
      }
      */
      return GetTickCount() - gtc_start_time;
   }
};

extern C_timer timer;

//----------------------------
//----------------------------
