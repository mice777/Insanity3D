/*--------------------------------------------------------
   File: Wave frequency converter
   Written by: Michal Bacik
   History:
      - created 20.12.1998    Michal Bacik
      - revisited 22.01.1999  Michal Bacik
      - ADPCM compression added 19.8.1999 Michal Bacik
      - Ogg compression added 30.4.2001 Michal Bacik
      - Ogg compression revisited, ADPCM removed 24.1.2002 MB

   Known bugs:

   Features:
      - converts 8, 16 and 32 -bit samples, mono and stereo
      - converts 16-bit samples to 1/2 size using ADPCM algo
      - compresses source to Ogg format
--------------------------------------------------------*/
#include <windows.h>
#include <rules.h>
#include <assert.h>
#include <direct.h>
#include <iostream>
#include <conio.h>
#include <fstream>
#include <c_str.hpp>
#include "vorbis\vorbisenc.h"

using namespace std;

//#define DEFAULT_ADPCM_COMPRESSION   4
//#define DEFAULT_OGG_COMPRESSION     128000
#define DEFAULT_OGG_COMPRESSION     .5

//----------------------------
//----------------------------

static void ADPCMCreate_table_16(short ampl_table[256], int type = 4){

   int i;

   const float range = 32768.0f;

   int d = -1;
   int e = 0;
   for(i=0; i<128; i++){
      float f = i / 128.0f;
      float bb = range;
      for(int j=0; j<type; j++)
         bb *= f;

      int c = (int)bb;
      if(c==d)
         e++;
      d = c;
      c += e;
      ampl_table[128+i] = c;
      ampl_table[128-i] = -c;
   }
   ampl_table[0] = ampl_table[1];
}

//----------------------------

static byte ADPCMFindIndex_16(int value, const short ampl_table[256]){

   int i;
   if(!value) return 128;
   if(value>0){
      for(i=128; i<256; i++)
         if(ampl_table[i]>value) return i-1;
      return 255;
   }else{
      for(i=128; i>=0; i--)
         if(ampl_table[i]<value) return i+1;
      return 1;
   }
}

//----------------------------

static void ADPCMCompress_16(const short *src, byte *dst, int num_samples, const short ampl_table[256], dword num_channels){

   int last[2];
   last[0] = 0;
   last[1] = 0;
   --num_channels;
   for(int i=0; i<num_samples; i++){
      int channel = i&num_channels;
      int val = src[i];
      byte indx = ADPCMFindIndex_16(val-last[channel], ampl_table);
      last[channel] += ampl_table[indx];
      assert(last[channel]<32768 && last[channel]>=-32768);
      dst[i] = indx;
   }
}

//----------------------------

static void ADPCMCreate_table_8(schar ampl_table[16], int type = 4){

   int i;

   const float range = 128.0f;

   int d = -1;
   int e = 0;
   for(i=0; i<9; i++){
      float f = i / 16.0f;
      float bb = range;
      for(int j=0; j<type; j++)
         bb *= f;

      int c = (int)bb;
      if(c==d)
         e++;
      d = c;
      c += e;
      if(i!=8)
         ampl_table[8+i] = c;
      ampl_table[8-i] = -c;
   }
}

//----------------------------

static byte ADPCMFindIndex_8(int value, const schar ampl_table[16]){

   int i;
   if(!value) return 8;
   if(value>0){
      for(i=8; i<16; i++){
         if(ampl_table[i]>value)
            return i-1;
      }
      return 15;
   }else{
      for(i=8; i>=0; i--){
         if(ampl_table[i]<value)
            return i+1;
      }
      return 0;
   }
}

//----------------------------

static void ADPCMCompress_8(const byte *src, byte *dst, int num_samples, const schar ampl_table[16], dword num_channels){

   int last[2];
   last[0] = 0;
   last[1] = 0;
   --num_channels;
   for(int i=0; i<num_samples; i++){
      int channel = i&num_channels;
      int val = (int)src[i] - 128;
      byte indx = ADPCMFindIndex_8(val-last[channel], ampl_table);
      assert(indx<16);
      last[channel] += ampl_table[indx];
      assert(last[channel]<128 && last[channel]>=-128);
      if(!(i&1))
         dst[i/2] = indx;
      else
         dst[i/2] |= indx<<4;
   }
}


//----------------------------

bool OggCompress(const short *src, ofstream &ostr, int num_samples,
   dword num_channels, dword sample_rate,
   //dword desired_bit_rate,
   float quality,
   bool verbose){

   vorbis_info vi;            //struct that stores all the static vorbis bitstream settings
   vorbis_comment vc;         //struct that stores all the user comments
   vorbis_dsp_state vd;       //central working state for the packet->PCM decoder
   vorbis_block vb;           //local working space for packet->PCM decode
   ogg_stream_state os;       //take physical pages, weld into a logical stream of packets
   ogg_page og;               //one Ogg bitstream page.  Vorbis packets are inside
   ogg_packet op;             //one raw packet of data for decode

   if(verbose)
      cout<<"- compressing... ";

   int ret;

                              //choose an encoding mode
   vorbis_info_init(&vi);
   //vorbis_encode_init(&vi, num_channels, sample_rate, -1, desired_bit_rate, -1);
   //ret = vorbis_encode_init(&vi, num_channels, sample_rate, -1, desired_bit_rate, -1);
   ret = vorbis_encode_init_vbr(&vi, num_channels, sample_rate, quality);
   if(ret)
      return false;
                              //add a comment
   vorbis_comment_init(&vc);
   vorbis_comment_add(&vc, "Encoded by Insanity compression utility.");
                              //set up the analysis state and auxiliary encoding storage
   vorbis_analysis_init(&vd, &vi);
   vorbis_block_init(&vd, &vb);

   ogg_stream_init(&os, 0);

  /* Vorbis streams begin with three headers; the initial header (with
     most of the codec setup parameters) which is mandated by the Ogg
     bitstream spec.  The second header holds any comment fields.  The
     third header holds the bitstream codebook.  We merely need to
     make the headers, then pass them to libvorbis one at a time;
     libvorbis handles the additional Ogg bitstream constraints */

   {
      ogg_packet header, header_comm, header_code;

      vorbis_analysis_headerout(&vd, &vc, &header, &header_comm, &header_code);
                              //automatically placed in its own page
      ogg_stream_packetin(&os, &header);
      ogg_stream_packetin(&os, &header_comm);
      ogg_stream_packetin(&os, &header_code);

   /* We don't have to write out here, but doing so makes streaming 
    * much easier, so we do, flushing ALL pages. This ensures the actual
    * audio data will start on a new page
    */
      while(true){
         int result = ogg_stream_flush(&os, &og);
         if(result==0)
            break;
         ostr.write((const char*)og.header, og.header_len);
         ostr.write((const char*)og.body, og.body_len);
      }
   }

   dword bytes_to_write = num_samples * num_channels * 2;
   dword bytes_written = 0;
   int last_progress = -1;
   while(bytes_written < bytes_to_write){
      int num_bytes = Min(4096ul, bytes_to_write - bytes_written);
      dword ns = num_bytes / (num_channels * 2);
                              //data to encode

                              //expose the buffer to submit data
      float **buffer = vorbis_analysis_buffer(&vd, ns);

                              //uninterleave samples
      const schar *readbuffer = ((const schar*)src) + bytes_written;
      switch(num_channels){
      case 1:
         {
            for(dword i=0; i<ns; i++){
               buffer[0][i] = ((readbuffer[i*2+1]<<8) | (0x00ff&(int)readbuffer[i*2])) / 32768.f;
            }
         }
         break;
      case 2:
         {
            for(dword i=0; i<ns; i++){
               buffer[0][i] = ((readbuffer[i*4+1]<<8) | (0x00ff&(int)readbuffer[i*4+0])) / 32768.f;
               buffer[1][i] = ((readbuffer[i*4+3]<<8) | (0x00ff&(int)readbuffer[i*4+2])) / 32768.f;
            }
         }
         break;
      default: assert(0);
      }
      bytes_written += num_bytes;

      if(verbose){
                              //show progress indicator
         int curr_progress = (float)100.0f * bytes_written / (float)bytes_to_write;
         if(last_progress != curr_progress){
            cout<<(const char*)C_fstr("%3i%%\b\b\b\b", last_progress=curr_progress);
         }
      }
         
                              //tell the library how much we actually submitted
      vorbis_analysis_wrote(&vd, ns);
      
      if(bytes_written == bytes_to_write){
                              //Tell the library we're at end of stream
                              // so that it can handle the last frame
                              // and mark end of stream in the output properly
         vorbis_analysis_wrote(&vd, 0);
      }

                              //vorbis does some data preanalysis,
                              // then divvies up blocks for
                              // more involved (potentially parallel) processing.
                              // Get a single block for encoding now
      while(vorbis_analysis_blockout(&vd, &vb)==1){
                              //analysis
         vorbis_analysis(&vb, &op);
                              //weld the packet into the bitstream
         ogg_stream_packetin(&os, &op);
                              //write out pages (if any)
         while(true){
            int result = ogg_stream_pageout(&os, &og);
            if(result==0)
               break;
            ostr.write((const char*)og.header, og.header_len);
            ostr.write((const char*)og.body, og.body_len);
                              //this could be set above, but for illustrative purposes,
                              // I do it here (to show that vorbis does know
                              // where the stream ends)
            if(ogg_page_eos(&og)){
               break;
            }
         }
      }
   }

                              //clean up and exit.  vorbis_info_clear() must be called last
   ogg_stream_clear(&os);
   vorbis_block_clear(&vb);
   vorbis_dsp_clear(&vd);
   vorbis_comment_clear(&vc);
   vorbis_info_clear(&vi);

   return true;
}

/*--------------------------------------------------------
   Create path to specified file, if not created yet.
--------------------------------------------------------*/

static bool CreatePath(const char *p1){

   C_str path(p1);
   dword sz = path.Size();
   for(dword i=0; i<sz; i++){
      if(path[i]=='\\'){
         path[i] = 0;
         mkdir(path);
         path[i] = '\\';
      }
   }
   return true;
}

//----------------------------

static void ClearLine(){
   for(dword i=79; i--; )
      cout<<' ';
   cout<<'\r';
}

//----------------------------

static bool WantEscape(){

   if(_kbhit() && _getch()==0x1b){
      ClearLine();
      cout<<"Are you sure to interrupt this operation? ";
      while(true){
         switch(_getch()){
         case 'y': case 'Y':
            cout<<"Y\n";
            return true;
         case 'n': case 'N':
            cout<<"N\n";
            return false;
         }
      }
   }
   return false;
}

//----------------------------

enum E_COMPRESS_MODE{
   COMPRESS_NO,
   COMPRESS_OGG,
   COMPRESS_ADPCM,
};

/*--------------------------------------------------------
   Function to convert Wave file, given source and destination file name
   and flags specifying behaviour.
--------------------------------------------------------*/

static bool ConvertFile(const char *in_file, const char *out_file,
   int new_freq,              //0 = no conversion
   bool verbose,
   bool overwrite,
   bool ovr_older,
   //int compress_mode,
   //int ogg_bitrate,
   E_COMPRESS_MODE compress,
   float ogg_quality,
   const C_str &extension,
   int &error){

   error = 0;

   MMIOINFO mmi;
   memset(&mmi, 0, sizeof(mmi));
   HMMIO mmh = mmioOpen((char*)(const char*)in_file, &mmi, MMIO_READ);
   if(!mmh){
      error = 1;              //can't open src
      return false;
   }

   C_str out_name = out_file;
   {
                              //change extension
      for(dword i=out_name.Size(); i--; ) if(out_name[i]=='\\') break;
      for(; i<out_name.Size(); i++) if(out_name[i]=='.') break;
      out_name[i] = 0;
      out_name = C_fstr("%s.%s", (const char*)out_name,
         extension.Size() ? (const char*)extension :
         //compress_mode ? "snd" : ogg_bitrate ? "ogg" : "wav");
      compress==COMPRESS_NO ? "wav" : compress==COMPRESS_OGG ? "ogg" : "snd");
   }

   if(verbose){
      ClearLine();
      cout<<"Wave \"" <<in_file <<"\"";
   }

                              //check if dest file exists
   {
      HANDLE out_hnd = CreateFile(out_name, GENERIC_READ, 0, NULL, OPEN_EXISTING, 0, NULL);
      if(out_hnd!=INVALID_HANDLE_VALUE){
         bool ovr = false;

         if(overwrite)
            ovr = true;
         else
         if(ovr_older){
                              //check file times
            HANDLE in_hnd = CreateFile(in_file, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL);
            FILETIME in_time, out_time;
            GetFileTime(in_hnd, NULL, NULL, &in_time);
            GetFileTime(out_hnd, NULL, NULL, &out_time);
            CloseHandle(in_hnd);
                              //compare times
            int comp = CompareFileTime(&in_time, &out_time);
            ovr = (comp>0);
            if(!ovr)
               ovr = (GetFileSize(out_hnd, NULL)==0);
         }
         CloseHandle(out_hnd);
                              //file exists
         if(!ovr){
            if(!ovr_older){
                              //complain
               if(verbose)
                  cout<<": file already exists: " <<(const char*)out_name <<endl;
               error = 2;     //dst exists
               return false;
            }
            if(verbose){
               cout<<": up to date\r";
            }
            return true;
         }
      }
   }

   MMCKINFO mmckInfoParent;
   MMCKINFO mmck_fmt, mmck_data;
   bool conv_ok = false;
                              //find wave chunk
   mmckInfoParent.fccType = mmioFOURCC('W','A','V','E');
   if(!mmioDescend(mmh, &mmckInfoParent, NULL, MMIO_FINDRIFF)){
                              //find fmt chunk
      mmck_fmt.ckid=mmioFOURCC('f','m','t',' ');
      if(!mmioDescend(mmh, &mmck_fmt, &mmckInfoParent, MMIO_FINDCHUNK)){
         dword dwSize = mmck_fmt.cksize;
                              //read wave format
         PCMWAVEFORMAT pcmwf;
         memset(&pcmwf, 0, sizeof(pcmwf));
         mmioRead(mmh, (LPSTR)&pcmwf.wf, Min(dwSize, (dword)sizeof(pcmwf)));
         mmioAscend(mmh, &mmck_fmt, 0);
                              //find data chunk
         mmck_data.ckid = mmioFOURCC('d','a','t','a');
         if(!mmioDescend(mmh, &mmck_data, &mmckInfoParent, MMIO_FINDCHUNK)){
            int sample_len = mmck_data.cksize;

            int bytes_per_sample = pcmwf.wf.nBlockAlign;
            int freq = pcmwf.wf.nSamplesPerSec;
            //int bps = pcmwf.wf.nBlockAlign / pcmwf.wf.nChannels * 8;
                              //create buffer and read data
            byte *mem = new byte[sample_len];

            if(mmioRead(mmh, (LPSTR)mem, sample_len) == (int)sample_len){

               conv_ok = true;
                              //write to file
               bool write_ok = false;

                              //for now compress only 16-bit files
               if(compress==COMPRESS_OGG){
                  if((pcmwf.wf.nBlockAlign / pcmwf.wf.nChannels) != 2){
                     if(verbose)
                        cout<<" - error: cannot compress " <<pcmwf.wf.nBlockAlign*8 <<"-bit data";
                     delete[] mem;
                     error = 3;
                     goto err;
                  }
               }

               HMMIO mmo = NULL;
               //if(!compress_mode && !ogg_bitrate)
               if(!compress){
                  mmo = mmioOpen((char*)(const char*)out_name, NULL, MMIO_CREATE | MMIO_READWRITE);
                  if(!mmo){
                              //try to create path
                     CreatePath(out_name);
                     mmo = mmioOpen((char*)(const char*)out_name, NULL, MMIO_CREATE | MMIO_READWRITE);
                  }
               }
               if(compress || mmo){
                  //if(!compress_mode && !ogg_bitrate)
                  if(!compress)
                     mmioCreateChunk(mmo, &mmckInfoParent, MMIO_CREATERIFF);

                  bool convert_freq = (new_freq);
                  if(!new_freq)
                     new_freq = pcmwf.wf.nSamplesPerSec;

                              //perform conversion
                  pcmwf.wf.nSamplesPerSec = new_freq;
                  pcmwf.wf.nAvgBytesPerSec = new_freq * pcmwf.wf.nBlockAlign;

                  byte *allocated_mem = NULL;
                  byte *new_mem = mem;
                  int new_len = sample_len;

                  int num_samples = sample_len / bytes_per_sample;

                  if(convert_freq && freq!=new_freq){
                              //convert frequency
                     double ratio = (float)freq / (float)new_freq;
                     int new_num_samples = (int)((float)num_samples / ratio);
                     new_len = new_num_samples * bytes_per_sample;
                     new_mem = allocated_mem = new byte[new_len];
                     double cnt = 0.0f;
                     switch(bytes_per_sample){
                     case 1:     //8-bit mono
                        {
                           for(int i=0; i<new_num_samples-1; i++, cnt += ratio){
                              new_mem[i] = mem[(int)cnt];
                           }
                              //last - watch double overflow!
                           new_mem[i] = mem[Min((int)cnt, num_samples-1)];
                        }
                        break;
                     case 2:     //8-bit stereo or 16-bit mono
                        {
                           short *memw = (short*)mem;
                           short *new_memw = (short*)new_mem;
                           for(int i=0; i<new_num_samples-1; i++, cnt += ratio){
                              new_memw[i] = memw[(int)cnt];
                           }
                              //last - watch double overflow!
                           new_memw[i] = memw[Min((int)cnt, num_samples-1)];
                        }
                        break;
                     case 4:     //16-bit stereo or 32-bit mono
                        {
                           long *memw = (long*)mem;
                           long *new_memw = (long*)new_mem;
                           for(int i=0; i<new_num_samples-1; i++, cnt += ratio){
                              new_memw[i] = memw[(int)cnt];
                           }
                              //last - watch double overflow!
                           new_memw[i] = memw[Min((int)cnt, num_samples-1)];
                        }
                        break;
                     case 8:     //32-bit stereo
                        {
                           struct S_smp{ long l[2]; };
                           S_smp *memw = (S_smp*)mem;
                           S_smp *new_memw = (S_smp*)new_mem;
                           for(int i=0; i<new_num_samples-1; i++, cnt += ratio){
                              new_memw[i] = memw[(int)cnt];
                           }
                              //last - watch double overflow!
                           new_memw[i] = memw[Min((int)cnt, num_samples-1)];
                        }
                        break;
                     }
                     num_samples = new_num_samples;
                  }
                  void *fmt_p = &pcmwf;
                  dword fmt_size = sizeof(pcmwf);

                              //can compress only 16-bit (mono) samples
                  if(compress==COMPRESS_ADPCM){
#pragma pack(push, 1)
                     struct S_adpcm_header{
                        dword fmt_id;
                        dword freq;
                        dword size_orig;
                        word num_chans;
                        word compr_type;
                     } hdr;
#pragma pack(pop)
                     hdr.fmt_id = 0x444e5349;   //'ISND'
                     hdr.num_chans = pcmwf.wf.nChannels;
                     hdr.freq = new_freq;
                     hdr.size_orig = new_len;
                     hdr.compr_type = 0;//compress_mode;

                     ofstream os;
                     os.open((const char*)out_name, ios::out | ios::binary);
                     if(os.fail()){
                        os.clear();
                              //try to create path
                        CreatePath(out_name);
                        os.open((const char*)out_name, ios::out | ios::binary);
                     }
                     if(!os.fail()){
                        os.write((const char*)&hdr, sizeof(hdr));
                              //compress
                        if(bytes_per_sample == 16){
                           short amp_tab[256];
                           ADPCMCreate_table_16(amp_tab);
                           byte *bp = new byte[new_len/2];
                           ADPCMCompress_16((const short*)new_mem, bp, new_len/2, amp_tab, hdr.num_chans);
                           os.write((const char*)bp, new_len/2);
                           delete[] bp;
                        }else{
                           schar amp_tab[16];
                           ADPCMCreate_table_8(amp_tab, 2);
                           byte *bp = new byte[new_len/2];
                           ADPCMCompress_8((const byte*)new_mem, bp, new_len & -2, amp_tab, hdr.num_chans);
                           os.write((const char*)bp, new_len/2);
                           delete[] bp;
                        }
                        os.close();

                        write_ok = true;
                     }
                  }else
                  if(compress==COMPRESS_OGG){
                     ofstream os;
                     os.open((const char*)out_name, ios::out | ios::binary);
                     if(os.fail()){
                        os.clear();
                              //try to create path
                        CreatePath(out_name);
                        os.open((const char*)out_name, ios::out | ios::binary);
                     }
                     if(!os.fail()){
                        bool ok = OggCompress((const short*)new_mem, os, num_samples,
                           pcmwf.wf.nChannels, new_freq, ogg_quality, verbose);
                        os.close();
                        if(ok){
                           write_ok = true;
                        }else{
                           if(verbose)
                              cout<<": cannot compress file " <<(const char*)out_name;
                           error = 6;        //can'compress
                        }
                     }
                  }else{

                              //write format chunk
                     mmioCreateChunk(mmo, &mmck_fmt, 0);
                     mmioWrite(mmo, (const char*)fmt_p, fmt_size);
                     mmioAscend(mmo, &mmck_fmt, 0);

                              //write data chunk
                     mmioCreateChunk(mmo, &mmck_data, 0);
                     mmioWrite(mmo, (const char*)new_mem, new_len);
                     mmioAscend(mmo, &mmck_data, 0);

                     mmioAscend(mmo, &mmckInfoParent, 0);
                     mmioClose(mmo, 0);

                     write_ok = true;
                  }
                  delete[] allocated_mem;
               }

               if(!write_ok && !error){
                  if(verbose)
                     cout<<": cannot write to file " <<(const char*)out_name;
                  error = 5;        //can't write dest data
               }
            }else{
               if(verbose)
                  cout<<": cannot read data";
               error = 4;        //can't read source data
            }
            delete[] mem;
         }else{
            if(verbose)
               cout<<": cannot read data";
            error = 4;        //can't read source data
         }
      }else{
         if(verbose)
            cout<<": cannot read data";
         error = 4;        //can't read source data
      }
   }else{
      if(verbose)
         cout<<": cannot read data";
      error = 3;        //unknown format
   }
err:
   mmioClose(mmh, 0);
   if(!conv_ok){
      if(verbose)
         cout<<" - error converting file " <<in_file;
   }
   if(verbose)
      cout<<endl;
   return conv_ok;
}

//----------------------------

static bool ConvertDir(const char *base_dir, const char *base_mask, const char *out_dir,
   int new_rate, bool verbose, bool overwrite, bool ovr_older,
   E_COMPRESS_MODE compress, float ogg_quality,
   const C_str &extension){

   WIN32_FIND_DATA fd;
   HANDLE h_seek;
                              //process files
   h_seek = FindFirstFile(C_fstr("%s\\%s", base_dir, base_mask), &fd);
   if(h_seek != INVALID_HANDLE_VALUE){
      do{
         if(fd.dwFileAttributes&(FILE_ATTRIBUTE_HIDDEN))
            continue;
         if(fd.dwFileAttributes&(FILE_ATTRIBUTE_DIRECTORY))
            continue;
         int error;
         bool st = ConvertFile(C_fstr("%s\\%s", base_dir, fd.cFileName),
            C_fstr("%s\\%s", out_dir, fd.cFileName),
            new_rate, verbose, overwrite, ovr_older,
            compress, ogg_quality,
            extension, error);
         if(!st && error >= 4){
            FindClose(h_seek);
            return false;
         }
         if(WantEscape()){
            FindClose(h_seek);
            return false;
         }

      } while(FindNextFile(h_seek, &fd));
      FindClose(h_seek);
   }

                              //process sub-dirs
   h_seek = FindFirstFile(C_fstr("%s\\*.*", base_dir), &fd);
   if(h_seek != INVALID_HANDLE_VALUE){
      do{
         if(fd.dwFileAttributes&(FILE_ATTRIBUTE_HIDDEN))
            continue;
         if(!(fd.dwFileAttributes&(FILE_ATTRIBUTE_DIRECTORY)))
            continue;
         if(fd.cFileName[0]=='.')
            continue;
         bool st = ConvertDir(C_fstr("%s\\%s", base_dir, fd.cFileName),
            base_mask,
            C_fstr("%s\\%s", out_dir, fd.cFileName),
            new_rate, verbose, overwrite, ovr_older,
            compress, ogg_quality,
            extension);
         if(!st){
            FindClose(h_seek);
            return false;
         }
      } while(FindNextFile(h_seek, &fd));
      FindClose(h_seek);
   }
   return true;
}

//----------------------------

int __cdecl main(int argc, char *argv[]){

   int i;

   int new_rate = 0;
   bool verbose = true;
   bool overwrite = false;
   bool ovr_older = false;
   E_COMPRESS_MODE compress = COMPRESS_NO;
   float ogg_quality = .5f;
   if(argc<3){
      cout<<"WAVE converter (c) 2001 Lonely Cat Games" <<endl
         <<"usage: wav_conv.exe <in_dir> <out_dir> [switches]" <<endl
         <<"switches:" <<endl
         <<"-c[n]    compress (ADPCM), n = table type (1-5, default = 4)" <<endl
         <<"-co[q]   compress (Ogg), q = quality (default = .5)" <<endl
         <<"-d       overwite older files" <<endl
         <<"-e<ext>  change default extension" <<endl
         <<"-f<n>    new frequency" <<endl
         <<"-o       overwite all existing files" <<endl
         <<"-q       quiet mode" <<endl;

      return 1;
   }

   char *in_dir = argv[1];
   char *out_dir = argv[2];
   C_str extension;
   C_str base_mask;
   for(i=strlen(in_dir); i--; ){
      if(in_dir[i]=='\\'){
         base_mask = &in_dir[i+1];
         in_dir[i] = 0;
         break;
      }
   }

   for(i=3; i<argc; i++){
      switch(argv[i][0]){
      case '-': case '//':
         switch(argv[i][1]){
         case 'q':
            verbose = false;
            break;
         case 'o':
            overwrite = true;
            break;
         case 'd':
            ovr_older = true;
            break;
         case 'f':
            new_rate = atoi(&argv[i][2]);
            break;
         case 'c':
            if(argv[i][2] == 'o'){
               ogg_quality = DEFAULT_OGG_COMPRESSION;
               //sscanf(&argv[i][3], "%i", &ogg_bitrate);
               sscanf(&argv[i][3], "%f", &ogg_quality);
               compress = COMPRESS_OGG;
            }else{
               compress = COMPRESS_ADPCM;
               /*
               sscanf(&argv[i][2], "%i", &compress_mode);
               if(compress_mode<1 || compress_mode>10){
                  cout<<"invalid compression mode: " <<compress_mode <<endl;
                  return 1;
               }
               */
            }
            break;
         case 'e':
            extension = &argv[i][2];
            break;
         }
         break;
      default:
         cout<<"invalid parameter: " <<argv[i] <<endl;
         return 1;
      }
   }

   bool st = ConvertDir(in_dir, base_mask, out_dir,
      new_rate, verbose, overwrite, ovr_older,
      //compress_mode, ogg_bitrate, extension);
      compress, ogg_quality, extension);
   if(verbose)
      ClearLine();

   return st ? 0 : 1;
}

//----------------------------
