	// Protocols for Physique Blended Vertex Interface classes	

	def_visible_generic(GetNode,			"GetNode");
	def_visible_generic(GetOffsetVector,	"GetOffsetVector");
	def_visible_generic(GetWeight,		"GetWeight");