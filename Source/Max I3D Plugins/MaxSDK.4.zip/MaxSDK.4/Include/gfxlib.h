#ifndef _GFXLIB_H_

#define _GFXLIB_H_

#define IMPORTING
#include "gfx.h"
#undef IMPORTING

#endif // _GFXLIB_H_
