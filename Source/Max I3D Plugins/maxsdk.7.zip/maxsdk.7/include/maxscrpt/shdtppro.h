// Protocol for Shadow Type class

	def_visible_generic (CanDoOmni, "CanDoOmni");
	def_visible_generic (SupportStdMapInterface, "SupportStdMapInterface");
	def_visible_generic (MapSize, "MapSize");
	
