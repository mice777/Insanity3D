/*	
 *		toolpro.h - def_generics for the operations on MouseTool
 *
 *			Copyright � John Wainwright 1996
 */

	def_visible_primitive(start_tool,	"startTool");
	def_visible_primitive(stop_tool,	"stopTool");

