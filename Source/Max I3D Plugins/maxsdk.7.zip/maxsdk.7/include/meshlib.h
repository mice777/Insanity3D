#ifndef _MESHLIB_H_

#define _MESHLIB_H_

#define IMPORTING
#include "mesh.h"
#undef IMPORTING

#endif // _MESHLIB_H_
