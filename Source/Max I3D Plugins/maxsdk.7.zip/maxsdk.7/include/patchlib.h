#ifndef _PATCHLIB_H_

#define _PATCHLIB_H_

//#define IMPORTING
#include "patch.h"
//#undef IMPORTING

#endif // _PATCHLIB_H_
